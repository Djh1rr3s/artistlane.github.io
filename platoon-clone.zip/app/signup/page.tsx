"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, ArrowLeft, Music, Headphones } from "lucide-react"
import { useRouter } from "next/navigation"
import { ArtistLaneLogo } from "@/components/artistlane-logo"

export default function SignUp() {
  const [step, setStep] = useState<1 | 2>(1)
  const [selectedRole, setSelectedRole] = useState<"artist" | "dj" | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleRoleSelection = (role: "artist" | "dj") => {
    setSelectedRole(role)
    setStep(2)
  }

  const handleOAuthSignUp = async (provider: "apple" | "google") => {
    setIsLoading(true)

    // Simulate OAuth signup flow
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock email generation based on provider and selected role
    const mockEmails = {
      apple: selectedRole === "artist" ? `newartist${Date.now()}@icloud.com` : `newdj${Date.now()}@icloud.com`,
      google: selectedRole === "artist" ? `newartist${Date.now()}@gmail.com` : `newdj${Date.now()}@gmail.com`,
    }

    const email = mockEmails[provider]

    // Store pending signup data
    localStorage.setItem("pendingUserRole", selectedRole || "artist")
    localStorage.setItem("pendingUserEmail", email)
    localStorage.setItem("pendingSignUpProvider", provider)

    // Redirect to plan selection
    router.push("/select-plan")
  }

  return (
    <div className="min-h-screen bg-black flex flex-col lg:flex-row">
      {/* Skip to content link for accessibility */}
      <a href="#signup-form" className="skip-to-content">
        Skip to signup form
      </a>

      {/* Left Side - Form */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8 min-h-screen lg:min-h-auto">
        <div className="w-full max-w-md">
          <Card
            id="signup-form"
            className="bg-gray-900/80 border-gray-800 backdrop-blur-sm shadow-2xl"
            role="main"
            aria-labelledby="signup-title"
          >
            <CardHeader className="text-center pb-6 px-4 sm:px-6 pt-6 sm:pt-8">
              <div className="mb-6">
                <ArtistLaneLogo size="lg" className="justify-center" />
              </div>
              <CardTitle id="signup-title" className="text-xl sm:text-2xl font-bold text-white mb-2">
                {step === 1 ? "Join ArtistLane" : "Create your account"}
              </CardTitle>
              <p className="text-gray-400 text-sm sm:text-base">
                {step === 1
                  ? "Choose your role to get started"
                  : `Sign up as ${selectedRole === "artist" ? "an Artist" : "a DJ"}`}
              </p>
            </CardHeader>

            <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6 pb-6 sm:pb-8">
              {step === 1 ? (
                // Step 1: Role Selection
                <div className="space-y-3 sm:space-y-4" role="group" aria-labelledby="role-selection-title">
                  <h2 id="role-selection-title" className="sr-only">
                    Select your role
                  </h2>

                  <Button
                    onClick={() => handleRoleSelection("artist")}
                    className="w-full h-14 sm:h-16 bg-gray-800/50 hover:bg-gray-700/50 border-2 border-gray-700 hover:border-purple-500 transition-all duration-300 group"
                    variant="outline"
                    aria-label="Select Artist role - Create, upload, and distribute music"
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center space-x-3 sm:space-x-4">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                          <Music className="w-4 h-4 sm:w-5 sm:h-5 text-white" aria-hidden="true" />
                        </div>
                        <div className="text-left">
                          <div className="text-white font-semibold text-sm sm:text-base">Artist</div>
                          <div className="text-gray-400 text-xs sm:text-sm">Create, upload, and distribute music</div>
                        </div>
                      </div>
                      <ArrowRight
                        className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 group-hover:text-white transition-colors"
                        aria-hidden="true"
                      />
                    </div>
                  </Button>

                  <Button
                    onClick={() => handleRoleSelection("dj")}
                    className="w-full h-14 sm:h-16 bg-gray-800/50 hover:bg-gray-700/50 border-2 border-gray-700 hover:border-purple-500 transition-all duration-300 group"
                    variant="outline"
                    aria-label="Select DJ role - Mix tracks, manage events, and perform"
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center space-x-3 sm:space-x-4">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                          <Headphones className="w-4 h-4 sm:w-5 sm:h-5 text-white" aria-hidden="true" />
                        </div>
                        <div className="text-left">
                          <div className="text-white font-semibold text-sm sm:text-base">DJ</div>
                          <div className="text-gray-400 text-xs sm:text-sm">Mix tracks, manage events, and perform</div>
                        </div>
                      </div>
                      <ArrowRight
                        className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 group-hover:text-white transition-colors"
                        aria-hidden="true"
                      />
                    </div>
                  </Button>
                </div>
              ) : (
                // Step 2: OAuth Sign Up
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4 sm:mb-6">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setStep(1)}
                      className="text-gray-400 hover:text-white p-0 flex items-center"
                      aria-label="Go back to role selection"
                    >
                      <ArrowLeft className="w-4 h-4 mr-1" aria-hidden="true" />
                      Back
                    </Button>
                    <div className="flex items-center space-x-2">
                      {selectedRole === "artist" ? (
                        <div className="flex items-center space-x-2 text-purple-400" aria-label="Selected role: Artist">
                          <Music className="w-4 h-4" aria-hidden="true" />
                          <span className="text-sm font-medium">Artist</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2 text-blue-400" aria-label="Selected role: DJ">
                          <Headphones className="w-4 h-4" aria-hidden="true" />
                          <span className="text-sm font-medium">DJ</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3 sm:space-y-4" role="group" aria-labelledby="oauth-title">
                    <h2 id="oauth-title" className="sr-only">
                      Sign up with social media
                    </h2>

                    {/* Apple Sign Up */}
                    <Button
                      onClick={() => handleOAuthSignUp("apple")}
                      disabled={isLoading}
                      className="w-full h-12 sm:h-14 bg-white text-black hover:bg-gray-100 transition-all duration-300 font-medium text-sm sm:text-base"
                      aria-label="Sign up with Apple"
                    >
                      <div className="flex items-center justify-center space-x-3">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                          <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
                        </svg>
                        <span>Sign up with Apple</span>
                      </div>
                    </Button>

                    {/* Google Sign Up */}
                    <Button
                      onClick={() => handleOAuthSignUp("google")}
                      disabled={isLoading}
                      variant="outline"
                      className="w-full h-12 sm:h-14 border-2 border-gray-600 text-white hover:bg-gray-800/50 hover:border-gray-500 transition-all duration-300 font-medium text-sm sm:text-base bg-transparent"
                      aria-label="Sign up with Google"
                    >
                      <div className="flex items-center justify-center space-x-3">
                        <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true">
                          <path
                            fill="#4285F4"
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                          />
                          <path
                            fill="#34A853"
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                          />
                          <path
                            fill="#FBBC05"
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                          />
                          <path
                            fill="#EA4335"
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                          />
                        </svg>
                        <span>Sign up with Google</span>
                      </div>
                    </Button>
                  </div>

                  {isLoading && (
                    <div className="flex items-center justify-center py-4" role="status" aria-live="polite">
                      <div className="flex items-center space-x-2 text-gray-400">
                        <div
                          className="w-4 h-4 border-2 border-gray-400 border-t-purple-500 rounded-full animate-spin"
                          aria-hidden="true"
                        ></div>
                        <span className="text-sm">Creating your account...</span>
                      </div>
                    </div>
                  )}

                  <div className="text-center text-xs text-gray-500 mt-4 sm:mt-6 pt-4 border-t border-gray-800">
                    By signing up, you agree to our{" "}
                    <a href="#" className="text-gray-400 hover:text-white underline">
                      Terms of Service
                    </a>{" "}
                    and{" "}
                    <a href="#" className="text-gray-400 hover:text-white underline">
                      Privacy Policy
                    </a>
                  </div>
                </div>
              )}

              <div className="text-center pt-4 border-t border-gray-800">
                <p className="text-gray-400 text-sm">
                  Already have an account?{" "}
                  <a href="/signin" className="text-purple-400 hover:text-purple-300 font-medium">
                    Sign in
                  </a>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Right Side - Visual */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-gray-900 via-purple-900/20 to-pink-900/20 items-center justify-center relative overflow-hidden min-h-screen">
        <div
          className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-gray-900 to-black"
          aria-hidden="true"
        ></div>

        {/* Animated background elements */}
        <div
          className="absolute top-20 left-20 w-2 h-2 bg-purple-500/40 rounded-full animate-pulse"
          aria-hidden="true"
        ></div>
        <div
          className="absolute top-40 right-32 w-1 h-1 bg-pink-500/60 rounded-full animate-pulse animation-delay-1000"
          aria-hidden="true"
        ></div>
        <div
          className="absolute bottom-40 left-16 w-3 h-3 bg-blue-500/30 rounded-full animate-pulse animation-delay-2000"
          aria-hidden="true"
        ></div>
        <div
          className="absolute top-1/3 right-20 w-1.5 h-1.5 bg-purple-400/50 rounded-full animate-pulse animation-delay-3000"
          aria-hidden="true"
        ></div>
        <div
          className="absolute bottom-1/3 right-40 w-2 h-2 bg-pink-400/40 rounded-full animate-pulse animation-delay-4000"
          aria-hidden="true"
        ></div>

        <div
          className="relative z-10 text-center space-y-8 max-w-lg px-8"
          role="complementary"
          aria-label="Signup benefits"
        >
          <div className="space-y-4">
            <div className="w-20 h-20 sm:w-24 sm:h-24 mx-auto bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-2xl">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center">
                {step === 1 ? (
                  <div
                    className="w-5 h-5 sm:w-6 sm:h-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full"
                    aria-hidden="true"
                  ></div>
                ) : selectedRole === "artist" ? (
                  <Music className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" aria-hidden="true" />
                ) : (
                  <Headphones className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" aria-hidden="true" />
                )}
              </div>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              {step === 1 ? "Start Your Journey" : `Welcome ${selectedRole === "artist" ? "Artist" : "DJ"}`}
            </h2>
            <p className="text-gray-300 text-base sm:text-lg leading-relaxed">
              {step === 1
                ? "Choose your path and join thousands of creators who trust ArtistLane with their music careers."
                : `Connect with ${
                    selectedRole === "artist" ? "fans and distribute your music" : "venues and share your mixes"
                  } worldwide. Your success story starts here.`}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4 sm:gap-6 pt-8">
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-1">500+</div>
              <div className="text-gray-400 text-xs sm:text-sm">{selectedRole === "artist" ? "Artists" : "DJs"}</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-1">50M+</div>
              <div className="text-gray-400 text-xs sm:text-sm">
                {selectedRole === "artist" ? "Streams" : selectedRole === "dj" ? "Plays" : "Streams"}
              </div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-1">100+</div>
              <div className="text-gray-400 text-xs sm:text-sm">Countries</div>
            </div>
          </div>

          <div className="flex justify-center space-x-4 pt-4" aria-hidden="true">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-pink-500 rounded-full animate-bounce animation-delay-200"></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce animation-delay-400"></div>
          </div>
        </div>
      </div>
    </div>
  )
}
