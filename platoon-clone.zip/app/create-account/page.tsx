"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, User, Mail, CreditCard } from "lucide-react"
import { useRouter } from "next/navigation"
import { ArtistLaneLogo } from "@/components/artistlane-logo"
import { PaymentModal } from "@/components/payment/payment-modal"

interface PlanData {
  planName: string
  price: string
  type: "artist" | "dj"
  features: string[]
}

export default function CreateAccount() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
  })
  const [selectedPlan, setSelectedPlan] = useState<PlanData | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const router = useRouter()

  useEffect(() => {
    // Get selected plan from localStorage
    const planData = localStorage.getItem("selectedPlan")
    if (planData) {
      setSelectedPlan(JSON.parse(planData))
    } else {
      // Redirect back to homepage if no plan selected
      router.push("/")
    }
  }, [router])

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required"
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Last name is required"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    // Store user data for after payment
    localStorage.setItem("userData", JSON.stringify(formData))

    if (selectedPlan?.price === "Free") {
      // For free plans, skip payment and go directly to dashboard
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("userRole", selectedPlan.type)
      localStorage.setItem("userEmail", formData.email)
      localStorage.setItem("paymentCompleted", "true")
      localStorage.setItem("activePlan", JSON.stringify(selectedPlan))

      if (selectedPlan.type === "dj") {
        router.push("/dj-dashboard")
      } else {
        router.push("/dashboard")
      }
    } else {
      // Show payment modal for paid plans
      setShowPaymentModal(true)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  if (!selectedPlan) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <Card className="w-full max-w-md bg-gray-900 border-gray-800">
        <CardHeader className="text-center">
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.push("/")}
              className="text-gray-400 hover:text-white p-0"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="text-sm text-gray-400 flex items-center">
              {selectedPlan.type === "artist" ? "🎵 Artist" : "🎧 DJ"}
              <span className="ml-2 text-purple-400">{selectedPlan.planName}</span>
            </div>
          </div>
          <ArtistLaneLogo className="mb-4" />
          <CardTitle className="text-2xl text-white">Create Your Account</CardTitle>
          <p className="text-gray-400">Join ArtistLane as {selectedPlan.type === "artist" ? "an Artist" : "a DJ"}</p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Plan Summary */}
          <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-white font-semibold">{selectedPlan.planName} Plan</h3>
                <p className="text-gray-400 text-sm capitalize">{selectedPlan.type}</p>
              </div>
              <div className="text-white font-bold">{selectedPlan.price}</div>
            </div>
          </div>

          {/* Account Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-gray-300 font-medium">
                  First Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className={`bg-gray-800 border-gray-700 text-white placeholder-gray-500 pl-10 focus:border-purple-500 focus:ring-purple-500 ${
                      errors.firstName ? "border-red-500" : ""
                    }`}
                    placeholder="John"
                  />
                </div>
                {errors.firstName && <p className="text-red-400 text-sm mt-1">{errors.firstName}</p>}
              </div>

              <div>
                <Label htmlFor="lastName" className="text-gray-300 font-medium">
                  Last Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className={`bg-gray-800 border-gray-700 text-white placeholder-gray-500 pl-10 focus:border-purple-500 focus:ring-purple-500 ${
                      errors.lastName ? "border-red-500" : ""
                    }`}
                    placeholder="Doe"
                  />
                </div>
                {errors.lastName && <p className="text-red-400 text-sm mt-1">{errors.lastName}</p>}
              </div>
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-300 font-medium">
                Email Address
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className={`bg-gray-800 border-gray-700 text-white placeholder-gray-500 pl-10 focus:border-purple-500 focus:ring-purple-500 ${
                    errors.email ? "border-red-500" : ""
                  }`}
                  placeholder="john.doe@example.com"
                />
              </div>
              {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 font-semibold py-3"
            >
              {selectedPlan.price === "Free" ? (
                <>
                  <User className="w-4 h-4 mr-2" />
                  Create Account
                </>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Continue to Payment
                </>
              )}
            </Button>
          </form>

          <div className="text-center text-xs text-gray-500">
            By creating an account, you agree to our{" "}
            <a href="#" className="text-gray-400 hover:text-white underline">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-gray-400 hover:text-white underline">
              Privacy Policy
            </a>
          </div>

          <div className="text-center">
            <p className="text-gray-400 text-sm">
              Already have an account?{" "}
              <a href="/signin" className="text-white hover:underline">
                Sign in
              </a>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Payment Modal */}
      {showPaymentModal && selectedPlan && (
        <PaymentModal isOpen={showPaymentModal} onClose={() => setShowPaymentModal(false)} plan={selectedPlan} />
      )}
    </div>
  )
}
