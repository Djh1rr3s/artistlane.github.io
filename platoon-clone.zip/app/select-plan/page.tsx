"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { ArtistLaneLogo } from "@/components/artistlane-logo"
import { PaymentModal } from "@/components/payment/payment-modal"
import { PageContainer } from "@/components/layout/page-container"

interface Plan {
  name: string
  price: string
  description: string
  features: string[]
  popular: boolean
  type: "artist" | "dj"
}

export default function SelectPlan() {
  const [userRole, setUserRole] = useState<"artist" | "dj" | null>(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Get user role from localStorage (set during signup)
    const role = localStorage.getItem("pendingUserRole") as "artist" | "dj"
    const email = localStorage.getItem("pendingUserEmail")
    const provider = localStorage.getItem("pendingSignUpProvider")

    if (!role || !email || !provider) {
      // Redirect back to signup if no pending signup data
      router.push("/signup")
      return
    }

    setUserRole(role)
  }, [router])

  const artistPlans: Plan[] = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for emerging artists",
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      popular: false,
      type: "artist",
    },
    {
      name: "Professional",
      price: "$39.99/year",
      description: "For serious artists and labels",
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "Marketing tools",
        "Custom release scheduling",
        "Revenue optimization",
      ],
      popular: true,
      type: "artist",
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For labels and large catalogs",
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      popular: false,
      type: "artist",
    },
  ]

  const djPlans: Plan[] = [
    {
      name: "Regular",
      price: "$49.99/year",
      description: "Perfect for emerging DJs",
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      popular: false,
      type: "dj",
    },
    {
      name: "Professional",
      price: "$89.99/year",
      description: "For serious DJs and labels",
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "Marketing tools",
        "Custom release scheduling",
        "Revenue optimization",
      ],
      popular: true,
      type: "dj",
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For labels and large catalogs",
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      popular: false,
      type: "dj",
    },
  ]

  const handlePlanSelection = (plan: Plan) => {
    setSelectedPlan(plan)

    if (plan.price === "Custom") {
      // Handle enterprise contact
      window.location.href = "mailto:sales@artistlane.com"
      return
    }

    if (plan.price === "Free") {
      // Complete signup for free plan
      completeSignup(plan)
    } else {
      // Show payment modal for paid plans
      setShowPaymentModal(true)
    }
  }

  const completeSignup = (plan: Plan) => {
    const email = localStorage.getItem("pendingUserEmail")
    const provider = localStorage.getItem("pendingSignUpProvider")
    const role = localStorage.getItem("pendingUserRole")

    // Complete the signup process
    localStorage.setItem("isAuthenticated", "true")
    localStorage.setItem("userRole", role || "artist")
    localStorage.setItem("userEmail", email || "")
    localStorage.setItem("signUpProvider", provider || "")
    localStorage.setItem("activePlan", JSON.stringify(plan))
    localStorage.setItem("paymentCompleted", plan.price === "Free" ? "true" : "false")

    // Generate mock user data
    localStorage.setItem("userFirstName", "New")
    localStorage.setItem("userLastName", "User")

    // Clean up pending data
    localStorage.removeItem("pendingUserRole")
    localStorage.removeItem("pendingUserEmail")
    localStorage.removeItem("pendingSignUpProvider")

    // Redirect to appropriate dashboard
    if (role === "dj") {
      router.push("/dj-dashboard")
    } else {
      router.push("/dashboard")
    }
  }

  if (!userRole) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    )
  }

  const plans = userRole === "artist" ? artistPlans : djPlans

  return (
    <div className="min-h-screen bg-black text-white">
      <PageContainer maxWidth="2xl" padding="lg">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            variant="ghost"
            onClick={() => router.push("/signup")}
            className="text-gray-400 hover:text-white flex items-center"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sign Up
          </Button>
          <ArtistLaneLogo />
        </div>

        {/* Plan Selection */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Badge className="bg-purple-600 text-white px-4 py-2">
              {userRole === "artist" ? "🎵 Artist" : "🎧 DJ"}
            </Badge>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Choose Your Plan</h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Select the perfect plan to start your {userRole === "artist" ? "music" : "DJ"} journey with ArtistLane.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-black/50 border-gray-800 hover:border-gray-600 transition-all duration-300 ${
                plan.popular ? "border-purple-500 scale-105" : ""
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                    <Star className="w-4 h-4 mr-1 fill-current" />
                    Most Popular
                  </div>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl md:text-2xl font-bold text-white">{plan.name}</CardTitle>
                <div className="text-2xl md:text-3xl font-bold text-white mb-2">{plan.price}</div>
                <p className="text-gray-400 text-sm md:text-base">{plan.description}</p>
              </CardHeader>

              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start text-gray-300 text-sm md:text-base">
                      <Check className="w-4 h-4 md:w-5 md:h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button
                  onClick={() => handlePlanSelection(plan)}
                  className={`w-full ${
                    plan.popular
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                      : "bg-gray-800 text-white hover:bg-gray-700"
                  }`}
                >
                  {plan.price === "Custom" ? "Contact Sales" : plan.price === "Free" ? "Get Started" : "Select Plan"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-400 text-sm">
            Need help choosing? Contact our team at{" "}
            <a href="mailto:support@artistlane.com" className="text-purple-400 hover:text-purple-300">
              support@artistlane.com
            </a>
          </p>
        </div>
      </PageContainer>

      {/* Payment Modal */}
      {showPaymentModal && selectedPlan && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          plan={{
            planName: selectedPlan.name,
            price: selectedPlan.price,
            type: selectedPlan.type,
          }}
        />
      )}
    </div>
  )
}
