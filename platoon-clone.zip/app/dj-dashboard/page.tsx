"use client"

import { useEffect, useState, Suspense, lazy } from "react"
import { useRouter } from "next/navigation"
import { Home, Calendar, MapPin, BarChart3, Upload, Users, Settings, Headphones, Mic, CreditCard } from "lucide-react"
import { ResponsiveDashboardLayout } from "@/components/dashboard/responsive-dashboard-layout"
import { DashboardSkeleton } from "@/components/ui/skeleton-loader"

// Lazy load components
const DJDashboardContent = lazy(() =>
  import("@/components/dj-dashboard/dj-dashboard-content").then((module) => ({ default: module.DJDashboardContent })),
)
const ProfileEditor = lazy(() =>
  import("@/components/profile/profile-editor").then((module) => ({ default: module.ProfileEditor })),
)
const PlanManagement = lazy(() =>
  import("@/components/plan-management/plan-management").then((module) => ({ default: module.PlanManagement })),
)

const menuItems = [
  { id: "overview", label: "Overview", icon: Home },
  { id: "mixes", label: "My Mixes", icon: Headphones },
  { id: "events", label: "Events", icon: Calendar },
  { id: "venues", label: "Venues", icon: MapPin },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "upload", label: "Upload Mix", icon: Upload },
  { id: "equipment", label: "Equipment", icon: Mic },
  { id: "audience", label: "Audience", icon: Users },
  { id: "billing", label: "Billing", icon: CreditCard },
  { id: "settings", label: "Settings", icon: Settings },
]

export default function DJDashboard() {
  const [activeSection, setActiveSection] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkAuth = async () => {
      // Simulate auth check delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const isAuthenticated = localStorage.getItem("isAuthenticated")
      const userRole = localStorage.getItem("userRole")

      if (!isAuthenticated) {
        router.push("/signin")
        return
      } else if (userRole !== "dj") {
        router.push("/dashboard")
        return
      }

      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const renderContent = () => {
    switch (activeSection) {
      case "billing":
        return (
          <Suspense fallback={<DashboardSkeleton />}>
            <PlanManagement />
          </Suspense>
        )
      case "settings":
        return (
          <Suspense fallback={<DashboardSkeleton />}>
            <ProfileEditor />
          </Suspense>
        )
      default:
        return (
          <Suspense fallback={<DashboardSkeleton />}>
            <DJDashboardContent activeSection={activeSection} />
          </Suspense>
        )
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="flex items-center space-x-3 text-white">
          <div className="w-6 h-6 border-2 border-gray-400 border-t-purple-500 rounded-full animate-spin"></div>
          <span>Loading DJ dashboard...</span>
        </div>
      </div>
    )
  }

  return (
    <ResponsiveDashboardLayout
      sidebarItems={menuItems}
      activeItem={activeSection}
      setActiveItem={setActiveSection}
      userRole="dj"
    >
      {renderContent()}
    </ResponsiveDashboardLayout>
  )
}
