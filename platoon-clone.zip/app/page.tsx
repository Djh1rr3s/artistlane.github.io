import { Suspense, lazy } from "react"
import { Header } from "@/components/header"
import { Skeleton } from "@/components/ui/skeleton-loader"

// Lazy load sections for better performance
const HeroSection = lazy(() => import("@/components/hero-section").then((module) => ({ default: module.HeroSection })))
const FeaturesSection = lazy(() =>
  import("@/components/features-section").then((module) => ({ default: module.FeaturesSection })),
)
const ServicesSection = lazy(() =>
  import("@/components/services-section").then((module) => ({ default: module.ServicesSection })),
)
const Footer = lazy(() => import("@/components/footer").then((module) => ({ default: module.Footer })))

function SectionSkeleton() {
  return (
    <div className="py-16 space-y-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center space-y-4 mb-12">
          <Skeleton className="h-12 w-96 mx-auto" />
          <Skeleton className="h-6 w-[600px] mx-auto" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-gray-900 rounded-lg p-6">
              <Skeleton className="h-6 w-32 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main id="main-content" role="main">
        <Suspense
          fallback={
            <div className="min-h-screen flex items-center justify-center">
              <div className="flex items-center space-x-3 text-white">
                <div className="w-6 h-6 border-2 border-gray-400 border-t-purple-500 rounded-full animate-spin"></div>
                <span>Loading...</span>
              </div>
            </div>
          }
        >
          <HeroSection />
        </Suspense>

        <Suspense fallback={<SectionSkeleton />}>
          <FeaturesSection />
        </Suspense>

        <Suspense fallback={<SectionSkeleton />}>
          <ServicesSection />
        </Suspense>
      </main>

      <Suspense fallback={<Skeleton className="h-64 w-full" />}>
        <Footer />
      </Suspense>
    </div>
  )
}
