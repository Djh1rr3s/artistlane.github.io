export interface UserPlan {
  planName: string
  price: string
  type: "artist" | "dj"
  features: string[]
  isActive: boolean
  expiresAt?: string
}

export interface UserProfile {
  email: string
  firstName: string
  lastName: string
  role: "artist" | "dj"
  plan: UserPlan
  isAuthenticated: boolean
  signInProvider?: "apple" | "google"
}

export class UserFlowManager {
  private static instance: UserFlowManager

  static getInstance(): UserFlowManager {
    if (!UserFlowManager.instance) {
      UserFlowManager.instance = new UserFlowManager()
    }
    return UserFlowManager.instance
  }

  // Mock database of users with their associated plans and roles
  private mockUserDatabase = new Map<string, UserProfile>([
    // Artist users
    [
      "artist@gmail.com",
      {
        email: "artist@gmail.com",
        firstName: "John",
        lastName: "Artist",
        role: "artist",
        plan: {
          planName: "Professional",
          price: "$39.99/year",
          type: "artist",
          features: ["Distribute to all platforms", "Advanced analytics"],
          isActive: true,
        },
        isAuthenticated: false,
        signInProvider: "google",
      },
    ],
    [
      "artist@icloud.com",
      {
        email: "artist@icloud.com",
        firstName: "Jane",
        lastName: "Singer",
        role: "artist",
        plan: {
          planName: "Starter",
          price: "Free",
          type: "artist",
          features: ["Distribute to 5 platforms", "Basic analytics"],
          isActive: true,
        },
        isAuthenticated: false,
        signInProvider: "apple",
      },
    ],
    // DJ users
    [
      "dj@gmail.com",
      {
        email: "dj@gmail.com",
        firstName: "Mike",
        lastName: "DJ",
        role: "dj",
        plan: {
          planName: "Professional",
          price: "$89.99/year",
          type: "dj",
          features: ["Distribute to all platforms", "Advanced analytics"],
          isActive: true,
        },
        isAuthenticated: false,
        signInProvider: "google",
      },
    ],
    [
      "dj@icloud.com",
      {
        email: "dj@icloud.com",
        firstName: "Sarah",
        lastName: "Mixer",
        role: "dj",
        plan: {
          planName: "Regular",
          price: "$49.99/year",
          type: "dj",
          features: ["Distribute to 5 platforms", "Basic analytics"],
          isActive: true,
        },
        isAuthenticated: false,
        signInProvider: "apple",
      },
    ],
  ])

  // Detect user role and plan based on email
  detectUserByEmail(email: string): UserProfile | null {
    // First check exact match
    const exactMatch = this.mockUserDatabase.get(email)
    if (exactMatch) {
      return exactMatch
    }

    // Fallback: detect role based on email patterns
    const emailLower = email.toLowerCase()
    const djKeywords = ["dj", "mix", "beat", "spin", "turntable"]
    const djDomains = ["djmix.com", "beatport.com", "serato.com"]

    const isDJ =
      djKeywords.some((keyword) => emailLower.includes(keyword)) ||
      djDomains.some((domain) => emailLower.includes(domain))

    // Create new user profile based on detection
    return {
      email,
      firstName: "New",
      lastName: "User",
      role: isDJ ? "dj" : "artist",
      plan: {
        planName: "Starter",
        price: "Free",
        type: isDJ ? "dj" : "artist",
        features: ["Distribute to 5 platforms", "Basic analytics"],
        isActive: true,
      },
      isAuthenticated: false,
    }
  }

  // Authenticate user and store session
  authenticateUser(email: string, provider: "apple" | "google"): UserProfile | null {
    const user = this.detectUserByEmail(email)
    if (!user) return null

    user.isAuthenticated = true
    user.signInProvider = provider

    // Store in localStorage
    localStorage.setItem("isAuthenticated", "true")
    localStorage.setItem("userRole", user.role)
    localStorage.setItem("userEmail", user.email)
    localStorage.setItem("userFirstName", user.firstName)
    localStorage.setItem("userLastName", user.lastName)
    localStorage.setItem("signInProvider", provider)
    localStorage.setItem("activePlan", JSON.stringify(user.plan))
    localStorage.setItem("userProfile", JSON.stringify(user))

    return user
  }

  // Get dashboard URL based on user role
  getDashboardUrl(role: "artist" | "dj"): string {
    return role === "dj" ? "/dj-dashboard" : "/dashboard"
  }

  // Check if user has access to specific features based on plan
  hasFeatureAccess(feature: string): boolean {
    const activePlan = localStorage.getItem("activePlan")
    if (!activePlan) return false

    const plan: UserPlan = JSON.parse(activePlan)
    return plan.features.some((f) => f.toLowerCase().includes(feature.toLowerCase()))
  }

  // Get plan limitations
  getPlanLimitations(): { [key: string]: number | boolean } {
    const activePlan = localStorage.getItem("activePlan")
    if (!activePlan) return {}

    const plan: UserPlan = JSON.parse(activePlan)

    // Define limitations based on plan
    const limitations: { [key: string]: { [key: string]: number | boolean } } = {
      Starter: {
        maxPlatforms: 5,
        advancedAnalytics: false,
        prioritySupport: false,
        marketingTools: false,
      },
      Regular: {
        maxPlatforms: 5,
        advancedAnalytics: false,
        prioritySupport: false,
        marketingTools: false,
      },
      Professional: {
        maxPlatforms: -1, // unlimited
        advancedAnalytics: true,
        prioritySupport: true,
        marketingTools: true,
      },
      Enterprise: {
        maxPlatforms: -1,
        advancedAnalytics: true,
        prioritySupport: true,
        marketingTools: true,
        dedicatedManager: true,
        customIntegrations: true,
      },
    }

    return limitations[plan.planName] || {}
  }

  // Clear user session
  signOut(): void {
    localStorage.clear()
  }
}
