"use client"

import { Button } from "@/components/ui/button"
import { Music, Users, TrendingUp } from "lucide-react"
import { PageContainer } from "@/components/layout/page-container"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-black overflow-hidden" role="banner">
      {/* Background gradient */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"
        aria-hidden="true"
      />

      {/* Animated background elements */}
      <div className="absolute inset-0" aria-hidden="true">
        <div className="absolute top-20 left-20 w-2 h-2 bg-purple-500/40 rounded-full animate-pulse" />
        <div className="absolute top-40 right-32 w-1 h-1 bg-pink-500/60 rounded-full animate-pulse animation-delay-1000" />
        <div className="absolute bottom-40 left-16 w-3 h-3 bg-blue-500/30 rounded-full animate-pulse animation-delay-2000" />
        <div className="absolute top-1/3 right-20 w-1.5 h-1.5 bg-purple-400/50 rounded-full animate-pulse animation-delay-3000" />
        <div className="absolute bottom-1/3 right-40 w-2 h-2 bg-pink-400/40 rounded-full animate-pulse animation-delay-4000" />
      </div>

      <PageContainer className="relative z-10 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Main heading */}
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
              Your Music,{" "}
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Everywhere
              </span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Distribute your music to all major platforms, connect with fans worldwide, and grow your career with
              ArtistLane's powerful tools.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold px-8 py-4 text-lg h-auto"
              asChild
            >
              <a href="/signup" aria-label="Start your music distribution journey">
                Start Your Journey
              </a>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-16 max-w-2xl mx-auto">
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-purple-600/20 rounded-lg mx-auto mb-3">
                <Music className="w-6 h-6 text-purple-400" aria-hidden="true" />
              </div>
              <div
                className="text-2xl sm:text-3xl font-bold text-white"
                aria-label="Over 10 thousand songs distributed"
              >
                10K+
              </div>
              <div className="text-gray-400 text-sm">Songs Distributed</div>
            </div>
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-pink-600/20 rounded-lg mx-auto mb-3">
                <Users className="w-6 h-6 text-pink-400" aria-hidden="true" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white" aria-label="Over 5 thousand active artists">
                5K+
              </div>
              <div className="text-gray-400 text-sm">Active Artists</div>
            </div>
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center w-12 h-12 bg-blue-600/20 rounded-lg mx-auto mb-3">
                <TrendingUp className="w-6 h-6 text-blue-400" aria-hidden="true" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-white" aria-label="50 million total streams">
                50M+
              </div>
              <div className="text-gray-400 text-sm">Total Streams</div>
            </div>
          </div>
        </div>
      </PageContainer>
    </section>
  )
}
