"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X, CreditCard, Lock } from "lucide-react"
import { useRouter } from "next/navigation"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  plan: {
    planName: string
    price: string
    type: string
  }
}

export function PaymentModal({ isOpen, onClose, plan }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<"card" | "paypal">("card")
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()
  const setIsLoading = setIsProcessing // Declare setIsLoading as an alias for setIsProcessing

  if (!isOpen) return null

  const handlePayment = async () => {
    setIsLoading(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Check if this is a signup flow or existing user upgrade
    const isSignupFlow = localStorage.getItem("pendingUserEmail")

    if (isSignupFlow) {
      // Complete signup flow
      const email = localStorage.getItem("pendingUserEmail")
      const provider = localStorage.getItem("pendingSignUpProvider")
      const role = localStorage.getItem("pendingUserRole")

      // Store authentication and user data
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("userRole", role || "artist")
      localStorage.setItem("userEmail", email || "")
      localStorage.setItem("signUpProvider", provider || "")
      localStorage.setItem("activePlan", JSON.stringify(plan))
      localStorage.setItem("paymentCompleted", "true")

      // Generate mock user data
      localStorage.setItem("userFirstName", "New")
      localStorage.setItem("userLastName", "User")

      // Clean up pending data
      localStorage.removeItem("pendingUserRole")
      localStorage.removeItem("pendingUserEmail")
      localStorage.removeItem("pendingSignUpProvider")

      // Redirect to appropriate dashboard
      if (role === "dj") {
        router.push("/dj-dashboard")
      } else {
        router.push("/dashboard")
      }
    } else {
      // Existing user upgrade flow
      const userData = localStorage.getItem("userData")

      if (userData) {
        const user = JSON.parse(userData)

        // Update user data
        localStorage.setItem("userFirstName", user.firstName)
        localStorage.setItem("userLastName", user.lastName)
        localStorage.setItem("paymentCompleted", "true")
        localStorage.setItem("activePlan", JSON.stringify(plan))

        // Clean up temporary data
        localStorage.removeItem("selectedPlan")
        localStorage.removeItem("userData")

        // Redirect to appropriate dashboard
        if (plan.type === "dj") {
          window.location.href = "/dj-dashboard"
        } else {
          window.location.href = "/dashboard"
        }
      }
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-900 border-gray-800 shadow-2xl">
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-800">
          <CardTitle className="text-white">Complete Payment</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-6 p-6">
          {/* Plan Summary */}
          <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-white font-semibold">{plan.planName} Plan</h3>
                <p className="text-gray-400 text-sm capitalize">{plan.type}</p>
              </div>
              <div className="text-white font-bold text-lg">{plan.price}</div>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="space-y-3">
            <Label className="text-gray-300 font-medium">Payment Method</Label>
            <div className="flex space-x-2">
              <Button
                variant={paymentMethod === "card" ? "default" : "outline"}
                className={`flex-1 ${
                  paymentMethod === "card"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                    : "border-gray-600 text-gray-300 hover:bg-gray-800 bg-gray-900"
                }`}
                onClick={() => setPaymentMethod("card")}
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Card
              </Button>
              <Button
                variant={paymentMethod === "paypal" ? "default" : "outline"}
                className={`flex-1 ${
                  paymentMethod === "paypal"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                    : "border-gray-600 text-gray-300 hover:bg-gray-800 bg-gray-900"
                }`}
                onClick={() => setPaymentMethod("paypal")}
              >
                PayPal
              </Button>
            </div>
          </div>

          {paymentMethod === "card" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="cardNumber" className="text-gray-300 font-medium">
                  Card Number
                </Label>
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry" className="text-gray-300 font-medium">
                    Expiry
                  </Label>
                  <Input
                    id="expiry"
                    placeholder="MM/YY"
                    className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <Label htmlFor="cvc" className="text-gray-300 font-medium">
                    CVC
                  </Label>
                  <Input
                    id="cvc"
                    placeholder="123"
                    className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="name" className="text-gray-300 font-medium">
                  Cardholder Name
                </Label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>
            </div>
          )}

          <div className="flex items-center space-x-2 text-gray-400 text-sm bg-gray-800/30 p-3 rounded-lg border border-gray-700">
            <Lock className="w-4 h-4 text-green-400" />
            <span>Your payment information is secure and encrypted</span>
          </div>

          <Button
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed py-3 font-semibold"
          >
            {isProcessing ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Processing Payment...</span>
              </div>
            ) : (
              `Complete Payment - ${plan.price}`
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
