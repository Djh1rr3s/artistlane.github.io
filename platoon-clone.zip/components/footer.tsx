import { ArtistLaneLogo } from "./artistlane-logo"
import { Twitter, Instagram, Youtube, Linkedin } from "lucide-react"
import { PageContainer } from "./layout/page-container"

export function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-12 no-print" role="contentinfo">
      <PageContainer maxWidth="2xl" padding="md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-2">
            <ArtistLaneLogo className="mb-4" />
            <p className="text-gray-400 mb-6 max-w-md">
              Empowering artists and DJs worldwide with innovative music distribution and marketing solutions. Join
              thousands who trust us with their music careers.
            </p>
            <div className="flex space-x-4 social-links" role="list" aria-label="Social media links">
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on Twitter"
              >
                <Twitter className="w-5 h-5" aria-hidden="true" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Follow us on Instagram"
              >
                <Instagram className="w-5 h-5" aria-hidden="true" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Subscribe to our YouTube channel"
              >
                <Youtube className="w-5 h-5" aria-hidden="true" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Connect with us on LinkedIn"
              >
                <Linkedin className="w-5 h-5" aria-hidden="true" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Services</h3>
            <nav role="navigation" aria-label="Services navigation">
              <ul className="space-y-2" role="list">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Learn about music distribution"
                  >
                    Music Distribution
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Learn about DJ services"
                  >
                    DJ Services
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="View analytics features"
                  >
                    Analytics
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Learn about marketing tools"
                  >
                    Marketing
                  </a>
                </li>
              </ul>
            </nav>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Company</h3>
            <nav role="navigation" aria-label="Company navigation">
              <ul className="space-y-2" role="list">
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Learn about our company"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="View career opportunities"
                  >
                    Careers
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Read press releases"
                  >
                    Press
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-gray-400 hover:text-white transition-colors"
                    aria-label="Contact our team"
                  >
                    Contact
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">© 2025 ArtistLane. All rights reserved.</p>
          <nav className="flex space-x-6 mt-4 md:mt-0" role="navigation" aria-label="Legal navigation">
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
              aria-label="Read our privacy policy"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
              aria-label="Read our terms of service"
            >
              Terms of Service
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
              aria-label="Read our cookie policy"
            >
              Cookie Policy
            </a>
          </nav>
        </div>
      </PageContainer>
    </footer>
  )
}
