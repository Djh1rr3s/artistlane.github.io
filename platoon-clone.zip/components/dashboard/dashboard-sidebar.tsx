"use client"
import { Button } from "@/components/ui/button"
import { Home, Music, BarChart3, DollarSign, Settings, Upload, Users, Calendar, User, CreditCard } from "lucide-react"

interface DashboardSidebarProps {
  activeItem: string
  setActiveItem: (item: string) => void
}

export function DashboardSidebar({ activeItem, setActiveItem }: DashboardSidebarProps) {
  const menuItems = [
    { id: "overview", label: "Overview", icon: Home },
    { id: "music", label: "My Music", icon: Music },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "earnings", label: "Earnings", icon: DollarSign },
    { id: "upload", label: "Upload", icon: Upload },
    { id: "audience", label: "Audience", icon: Users },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "profile", label: "Profile", icon: User },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <aside className="w-64 bg-gray-900 border-r border-gray-800 min-h-screen">
      <nav className="p-4">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              className={`w-full justify-start text-left ${
                activeItem === item.id ? "bg-gray-800 text-white" : "text-gray-400 hover:text-white hover:bg-gray-800"
              }`}
              onClick={() => setActiveItem(item.id)}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.label}
            </Button>
          ))}
        </div>
      </nav>
    </aside>
  )
}
