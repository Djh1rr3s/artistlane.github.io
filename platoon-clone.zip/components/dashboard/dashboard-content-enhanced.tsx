import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Play, Download, Eye, Heart, Upload } from "lucide-react"
import { UploadSection } from "./upload-section"
import { AnalyticsCharts } from "./analytics-charts"
import { FeatureGate } from "@/components/plan-gates/feature-gate"
import { UsageIndicator } from "@/components/plan-gates/usage-indicator"

interface DashboardContentProps {
  activeSection: string
}

export function DashboardContentEnhanced({ activeSection }: DashboardContentProps) {
  // Get user name from localStorage
  const firstName = localStorage.getItem("userFirstName") || "Artist"
  const lastName = localStorage.getItem("userLastName") || ""
  const fullName = `${firstName} ${lastName}`.trim()

  const recentTracks = [
    {
      title: "Midnight Dreams",
      plays: "45,231",
      revenue: "$234.56",
      trend: "up",
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      title: "Electric Pulse",
      plays: "32,187",
      revenue: "$187.43",
      trend: "up",
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      title: "Neon Nights",
      plays: "28,945",
      revenue: "$156.78",
      trend: "down",
      image: "/placeholder.svg?height=60&width=60",
    },
  ]

  if (activeSection === "upload") {
    return (
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Upload Music</h1>
          <p className="text-gray-400">Share your latest tracks with the world.</p>
        </div>
        <FeatureGate feature="upload" requiredPlan="Professional">
          <UploadSection />
        </FeatureGate>
      </div>
    )
  }

  if (activeSection === "analytics") {
    return (
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Analytics</h1>
          <p className="text-gray-400">Track your music performance and audience insights.</p>
        </div>
        <FeatureGate feature="advanced analytics" requiredPlan="Professional">
          <AnalyticsCharts />
        </FeatureGate>
      </div>
    )
  }

  // Default overview section
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {fullName}</h1>
        <p className="text-gray-400">Here's what's happening with your music today.</p>
      </div>

      {/* Usage Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <UsageIndicator feature="platforms" current={3} label="Platforms Used" />

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Streams</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">2.4M</div>
            <div className="flex items-center text-sm text-green-500">
              <TrendingUp className="w-4 h-4 mr-1" />
              +12.5% from last month
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">$3,247</div>
            <div className="flex items-center text-sm text-green-500">
              <TrendingUp className="w-4 h-4 mr-1" />
              +8.2% from last month
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Active Listeners</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">156K</div>
            <div className="flex items-center text-sm text-red-500">
              <TrendingDown className="w-4 h-4 mr-1" />
              -2.1% from last month
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tracks */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Recent Tracks Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTracks.map((track, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-lg bg-gray-800/50">
                  <img src={track.image || "/placeholder.svg"} alt={track.title} className="w-12 h-12 rounded-lg" />
                  <div className="flex-1">
                    <h4 className="font-medium text-white">{track.title}</h4>
                    <div className="flex items-center space-x-4 text-sm text-gray-400">
                      <span className="flex items-center">
                        <Play className="w-3 h-3 mr-1" />
                        {track.plays}
                      </span>
                      <span>{track.revenue}</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {track.trend === "up" ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <FeatureGate
                feature="upload"
                fallback={
                  <Button disabled className="w-full bg-gray-700 text-gray-400 cursor-not-allowed justify-start">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload New Track (Upgrade Required)
                  </Button>
                }
              >
                <Button className="w-full bg-white text-black hover:bg-gray-200 justify-start">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload New Track
                </Button>
              </FeatureGate>

              <FeatureGate
                feature="advanced analytics"
                fallback={
                  <Button
                    disabled
                    variant="outline"
                    className="w-full border-gray-600 text-gray-400 cursor-not-allowed justify-start bg-transparent"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Advanced Analytics (Pro Feature)
                  </Button>
                }
              >
                <Button
                  variant="outline"
                  className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </FeatureGate>

              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Reports
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
              >
                <Heart className="w-4 h-4 mr-2" />
                Engage with Fans
              </Button>
            </div>

            <div className="mt-6 p-4 bg-gray-800/50 rounded-lg">
              <h4 className="font-medium text-white mb-2">Upload Progress</h4>
              <p className="text-sm text-gray-400 mb-2">Processing "Summer Vibes"</p>
              <Progress value={75} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">75% complete</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
