"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts"

const streamData = [
  { month: "Jan", streams: 45000, revenue: 234 },
  { month: "Feb", streams: 52000, revenue: 287 },
  { month: "Mar", streams: 48000, revenue: 256 },
  { month: "Apr", streams: 61000, revenue: 342 },
  { month: "May", streams: 55000, revenue: 298 },
  { month: "Jun", streams: 67000, revenue: 389 },
]

const platformData = [
  { name: "Spotify", value: 45, color: "#1DB954" },
  { name: "Apple Music", value: 25, color: "#FA57C1" },
  { name: "YouTube Music", value: 15, color: "#FF0000" },
  { name: "Amazon Music", value: 10, color: "#FF9900" },
  { name: "Others", value: 5, color: "#8B5CF6" },
]

const topTracksData = [
  { name: "Midnight Dreams", streams: 125000 },
  { name: "Electric Pulse", streams: 98000 },
  { name: "Neon Nights", streams: 87000 },
  { name: "Digital Love", streams: 76000 },
  { name: "Cyber Dreams", streams: 65000 },
]

const audienceData = [
  { age: "18-24", listeners: 35 },
  { age: "25-34", listeners: 45 },
  { age: "35-44", listeners: 15 },
  { age: "45-54", listeners: 4 },
  { age: "55+", listeners: 1 },
]

export function AnalyticsCharts() {
  return (
    <div className="space-y-6">
      {/* Streams and Revenue Over Time */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Streams Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                streams: {
                  label: "Streams",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={streamData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="streams"
                    stroke="var(--color-streams)"
                    fill="var(--color-streams)"
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                revenue: {
                  label: "Revenue ($)",
                  color: "hsl(var(--chart-2))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={streamData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="var(--color-revenue)"
                    strokeWidth={3}
                    dot={{ fill: "var(--color-revenue)", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Platform Distribution and Top Tracks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Platform Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                spotify: { label: "Spotify", color: "#1DB954" },
                apple: { label: "Apple Music", color: "#FA57C1" },
                youtube: { label: "YouTube Music", color: "#FF0000" },
                amazon: { label: "Amazon Music", color: "#FF9900" },
                others: { label: "Others", color: "#8B5CF6" },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={platformData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {platformData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Top Performing Tracks</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                streams: {
                  label: "Streams",
                  color: "hsl(var(--chart-3))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topTracksData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis type="number" stroke="#9CA3AF" />
                  <YAxis dataKey="name" type="category" stroke="#9CA3AF" width={100} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="streams" fill="var(--color-streams)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Audience Demographics */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Audience Demographics</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              listeners: {
                label: "Listeners (%)",
                color: "hsl(var(--chart-4))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={audienceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="age" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="listeners" fill="var(--color-listeners)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
