"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Upload, Music, X, CheckCircle } from "lucide-react"

interface UploadFile {
  id: string
  name: string
  size: number
  progress: number
  status: "uploading" | "completed" | "error"
}

export function UploadSection() {
  const [dragActive, setDragActive] = useState(false)
  const [files, setFiles] = useState<UploadFile[]>([])
  const [trackInfo, setTrackInfo] = useState({
    title: "",
    artist: "",
    genre: "",
    description: "",
  })

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files)
    }
  }, [])

  const handleFiles = (fileList: FileList) => {
    const newFiles: UploadFile[] = Array.from(fileList).map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      progress: 0,
      status: "uploading" as const,
    }))

    setFiles((prev) => [...prev, ...newFiles])

    // Simulate upload progress
    newFiles.forEach((file) => {
      const interval = setInterval(() => {
        setFiles((prev) =>
          prev.map((f) => {
            if (f.id === file.id) {
              const newProgress = f.progress + Math.random() * 20
              if (newProgress >= 100) {
                clearInterval(interval)
                return { ...f, progress: 100, status: "completed" }
              }
              return { ...f, progress: newProgress }
            }
            return f
          }),
        )
      }, 500)
    })
  }

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id))
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Upload Music</CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-300 ${
              dragActive
                ? "border-purple-500 bg-purple-500/10 scale-105"
                : "border-gray-600 hover:border-gray-500 hover:bg-gray-800/30"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Upload className="w-8 h-8 text-purple-400" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">Drop your music files here</h3>
            <p className="text-gray-400 mb-4">or click to browse</p>
            <input
              type="file"
              multiple
              accept="audio/*"
              className="hidden"
              id="file-upload"
              onChange={(e) => e.target.files && handleFiles(e.target.files)}
            />
            <Button
              asChild
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
            >
              <label htmlFor="file-upload" className="cursor-pointer">
                Choose Files
              </label>
            </Button>
            <p className="text-xs text-gray-500 mt-2">Supported formats: MP3, WAV, FLAC, M4A</p>
          </div>

          {files.length > 0 && (
            <div className="mt-6 space-y-3">
              <h4 className="text-white font-medium">Uploading Files</h4>
              {files.map((file) => (
                <div key={file.id} className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-lg flex items-center justify-center">
                        <Music className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{file.name}</p>
                        <p className="text-gray-400 text-sm">{formatFileSize(file.size)}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {file.status === "completed" && <CheckCircle className="w-5 h-5 text-green-500" />}
                      <button
                        onClick={() => removeFile(file.id)}
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <Progress value={file.progress} className="h-2 bg-gray-700" />
                  <p className="text-xs text-gray-400 mt-1">
                    {file.status === "completed" ? "Upload complete" : `${Math.round(file.progress)}% uploaded`}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Track Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title" className="text-gray-300 font-medium">
                Track Title
              </Label>
              <Input
                id="title"
                value={trackInfo.title}
                onChange={(e) => setTrackInfo((prev) => ({ ...prev, title: e.target.value }))}
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                placeholder="Enter track title"
              />
            </div>
            <div>
              <Label htmlFor="artist" className="text-gray-300 font-medium">
                Artist Name
              </Label>
              <Input
                id="artist"
                value={trackInfo.artist}
                onChange={(e) => setTrackInfo((prev) => ({ ...prev, artist: e.target.value }))}
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
                placeholder="Enter artist name"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="genre" className="text-gray-300 font-medium">
              Genre
            </Label>
            <Input
              id="genre"
              value={trackInfo.genre}
              onChange={(e) => setTrackInfo((prev) => ({ ...prev, genre: e.target.value }))}
              className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
              placeholder="e.g., Electronic, Hip Hop, Rock"
            />
          </div>

          <div>
            <Label htmlFor="description" className="text-gray-300 font-medium">
              Description
            </Label>
            <Textarea
              id="description"
              value={trackInfo.description}
              onChange={(e) => setTrackInfo((prev) => ({ ...prev, description: e.target.value }))}
              className="bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-purple-500"
              placeholder="Tell us about your track..."
              rows={3}
            />
          </div>

          <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 font-semibold py-3">
            Publish Track
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
