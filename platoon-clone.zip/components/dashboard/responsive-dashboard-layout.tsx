"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Menu, X, Bell, Search, User, LogOut } from "lucide-react"
import { ArtistLaneLogo } from "@/components/artistlane-logo"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ResponsiveDashboardLayoutProps {
  children: React.ReactNode
  sidebarItems: Array<{
    id: string
    label: string
    icon: React.ComponentType<{ className?: string }>
  }>
  activeItem: string
  setActiveItem: (item: string) => void
  userRole: "artist" | "dj"
  pageTitle?: string
}

export function ResponsiveDashboardLayout({
  children,
  sidebarItems,
  activeItem,
  setActiveItem,
  userRole,
  pageTitle,
}: ResponsiveDashboardLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024)
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(false)
      }
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  const handleLogout = () => {
    localStorage.clear()
    window.location.href = "/"
  }

  const closeSidebar = () => {
    setIsSidebarOpen(false)
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Mobile Header */}
      <div className="lg:hidden bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-3">
          <ArtistLaneLogo size="sm" />
          <Badge className={`text-xs ${userRole === "dj" ? "bg-purple-600" : "bg-blue-600"}`}>
            {userRole === "dj" ? "🎧 DJ" : "🎵 Artist"}
          </Badge>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="text-gray-400 hover:text-white"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 relative">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-64 bg-gray-900 border-r border-gray-800 flex-col">
          {/* Desktop Header */}
          <div className="p-4 border-b border-gray-800">
            <ArtistLaneLogo className="mb-3" />
            <Badge className={`text-xs ${userRole === "dj" ? "bg-purple-600" : "bg-blue-600"}`}>
              {userRole === "dj" ? "🎧 DJ Dashboard" : "🎵 Artist Dashboard"}
            </Badge>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 overflow-y-auto">
            <div className="space-y-1">
              {sidebarItems.map((item) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={`w-full justify-start text-left ${
                    activeItem === item.id
                      ? `${userRole === "dj" ? "bg-purple-600" : "bg-blue-600"} text-white`
                      : "text-gray-400 hover:text-white hover:bg-gray-800"
                  }`}
                  onClick={() => setActiveItem(item.id)}
                >
                  <item.icon className="w-4 h-4 mr-3" />
                  {item.label}
                </Button>
              ))}
            </div>
          </nav>

          {/* User Menu */}
          <div className="p-4 border-t border-gray-800">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-800"
                >
                  <User className="w-4 h-4 mr-3" />
                  Account
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-gray-800 border-gray-700" align="end">
                <DropdownMenuItem className="text-white hover:bg-gray-700">
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout} className="text-red-400 hover:bg-gray-700">
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </aside>

        {/* Mobile Sidebar Overlay */}
        {isSidebarOpen && isMobile && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="fixed inset-0 bg-black/50" onClick={closeSidebar} />
            <div className="fixed left-0 top-0 h-full w-64 bg-gray-900 border-r border-gray-800 flex flex-col">
              <div className="p-4 border-b border-gray-800">
                <ArtistLaneLogo className="mb-3" />
                <Badge className={`text-xs ${userRole === "dj" ? "bg-purple-600" : "bg-blue-600"}`}>
                  {userRole === "dj" ? "🎧 DJ Dashboard" : "🎵 Artist Dashboard"}
                </Badge>
              </div>

              <nav className="flex-1 p-4 overflow-y-auto">
                <div className="space-y-1">
                  {sidebarItems.map((item) => (
                    <Button
                      key={item.id}
                      variant="ghost"
                      className={`w-full justify-start text-left ${
                        activeItem === item.id
                          ? `${userRole === "dj" ? "bg-purple-600" : "bg-blue-600"} text-white`
                          : "text-gray-400 hover:text-white hover:bg-gray-800"
                      }`}
                      onClick={() => {
                        setActiveItem(item.id)
                        closeSidebar()
                      }}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.label}
                    </Button>
                  ))}
                </div>
              </nav>

              <div className="p-4 border-t border-gray-800">
                <Button
                  variant="ghost"
                  onClick={handleLogout}
                  className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-gray-800"
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Desktop Top Bar */}
          <div className="hidden lg:flex bg-gray-900 border-b border-gray-800 px-6 py-3 items-center justify-between">
            <h1 className="text-xl font-semibold text-white">
              {pageTitle || sidebarItems.find((item) => item.id === activeItem)?.label || "Dashboard"}
            </h1>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-gray-600 w-64"
                />
              </div>

              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    <User className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-gray-800 border-gray-700">
                  <DropdownMenuItem className="text-white hover:bg-gray-700">Profile</DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} className="text-red-400 hover:bg-gray-700">
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Page Content */}
          <div className="flex-1 overflow-auto">{children}</div>
        </main>
      </div>
    </div>
  )
}
