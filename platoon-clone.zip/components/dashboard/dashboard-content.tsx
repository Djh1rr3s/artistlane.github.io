import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Play, Download, Eye, Heart, Upload } from "lucide-react"
import { OptimizedImage } from "@/components/ui/optimized-image"
import { Suspense, lazy } from "react"
import { CardSkeleton } from "@/components/ui/skeleton-loader"

// Lazy load heavy components
const UploadSection = lazy(() => import("./upload-section").then((module) => ({ default: module.UploadSection })))
const AnalyticsCharts = lazy(() => import("./analytics-charts").then((module) => ({ default: module.AnalyticsCharts })))

interface DashboardContentProps {
  activeSection: string
}

export function DashboardContent({ activeSection }: DashboardContentProps) {
  // Get user name from localStorage
  const firstName = localStorage.getItem("userFirstName") || "Artist"
  const lastName = localStorage.getItem("userLastName") || ""
  const fullName = `${firstName} ${lastName}`.trim()

  const recentTracks = [
    {
      title: "Midnight Dreams",
      plays: "45,231",
      revenue: "$234.56",
      trend: "up",
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      title: "Electric Pulse",
      plays: "32,187",
      revenue: "$187.43",
      trend: "up",
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      title: "Neon Nights",
      plays: "28,945",
      revenue: "$156.78",
      trend: "down",
      image: "/placeholder.svg?height=60&width=60",
    },
  ]

  if (activeSection === "upload") {
    return (
      <div className="p-4 md:p-6">
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Upload Music</h1>
          <p className="text-gray-400">Share your latest tracks with the world.</p>
        </div>
        <Suspense fallback={<CardSkeleton />}>
          <UploadSection />
        </Suspense>
      </div>
    )
  }

  if (activeSection === "analytics") {
    return (
      <div className="p-4 md:p-6">
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Analytics</h1>
          <p className="text-gray-400">Track your music performance and audience insights.</p>
        </div>
        <Suspense fallback={<CardSkeleton />}>
          <AnalyticsCharts />
        </Suspense>
      </div>
    )
  }

  // Default overview section
  return (
    <div className="p-4 md:p-6">
      <div className="mb-6 md:mb-8">
        <h1 className="text-xl md:text-2xl lg:text-3xl font-bold mb-2">Welcome back, {fullName}</h1>
        <p className="text-gray-400">Here's what's happening with your music today.</p>
      </div>

      {/* Stats Cards - Responsive Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 mb-6 md:mb-8">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2 px-3 md:px-6 pt-3 md:pt-6">
            <CardTitle className="text-xs md:text-sm font-medium text-gray-400">Total Streams</CardTitle>
          </CardHeader>
          <CardContent className="px-3 md:px-6 pb-3 md:pb-6">
            <div className="text-lg md:text-2xl font-bold text-white">2.4M</div>
            <div className="flex items-center text-xs md:text-sm text-green-500">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +12.5%
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2 px-3 md:px-6 pt-3 md:pt-6">
            <CardTitle className="text-xs md:text-sm font-medium text-gray-400">Revenue</CardTitle>
          </CardHeader>
          <CardContent className="px-3 md:px-6 pb-3 md:pb-6">
            <div className="text-lg md:text-2xl font-bold text-white">$3,247</div>
            <div className="flex items-center text-xs md:text-sm text-green-500">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +8.2%
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2 px-3 md:px-6 pt-3 md:pt-6">
            <CardTitle className="text-xs md:text-sm font-medium text-gray-400">Listeners</CardTitle>
          </CardHeader>
          <CardContent className="px-3 md:px-6 pb-3 md:pb-6">
            <div className="text-lg md:text-2xl font-bold text-white">156K</div>
            <div className="flex items-center text-xs md:text-sm text-red-500">
              <TrendingDown className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              -2.1%
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2 px-3 md:px-6 pt-3 md:pt-6">
            <CardTitle className="text-xs md:text-sm font-medium text-gray-400">Followers</CardTitle>
          </CardHeader>
          <CardContent className="px-3 md:px-6 pb-3 md:pb-6">
            <div className="text-lg md:text-2xl font-bold text-white">89.2K</div>
            <div className="flex items-center text-xs md:text-sm text-green-500">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +15.3%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content - Responsive Layout */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 md:gap-6">
        {/* Recent Tracks */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="px-4 md:px-6">
            <CardTitle className="text-white text-lg md:text-xl">Recent Tracks Performance</CardTitle>
          </CardHeader>
          <CardContent className="px-4 md:px-6">
            <div className="space-y-3 md:space-y-4">
              {recentTracks.map((track, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-3 md:space-x-4 p-2 md:p-3 rounded-lg bg-gray-800/50"
                >
                  <OptimizedImage
                    src={track.image}
                    alt={track.title}
                    width={48}
                    height={48}
                    className="w-10 h-10 md:w-12 md:h-12 rounded-lg flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-white text-sm md:text-base truncate">{track.title}</h4>
                    <div className="flex items-center space-x-3 md:space-x-4 text-xs md:text-sm text-gray-400">
                      <span className="flex items-center">
                        <Play className="w-3 h-3 mr-1" />
                        {track.plays}
                      </span>
                      <span>{track.revenue}</span>
                    </div>
                  </div>
                  <div className="flex items-center flex-shrink-0">
                    {track.trend === "up" ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="px-4 md:px-6">
            <CardTitle className="text-white text-lg md:text-xl">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="px-4 md:px-6">
            <div className="space-y-3 md:space-y-4">
              <Button className="w-full bg-white text-black hover:bg-gray-200 justify-start text-sm md:text-base h-10 md:h-12">
                <Upload className="w-4 h-4 mr-2" />
                Upload New Track
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent text-sm md:text-base h-10 md:h-12"
              >
                <Eye className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent text-sm md:text-base h-10 md:h-12"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Reports
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent text-sm md:text-base h-10 md:h-12"
              >
                <Heart className="w-4 h-4 mr-2" />
                Engage with Fans
              </Button>
            </div>

            <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gray-800/50 rounded-lg">
              <h4 className="font-medium text-white mb-2 text-sm md:text-base">Upload Progress</h4>
              <p className="text-xs md:text-sm text-gray-400 mb-2">Processing "Summer Vibes"</p>
              <Progress value={75} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">75% complete</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
