"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { ArtistLaneLogo } from "@/components/artistlane-logo"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const closeMenu = () => {
    setIsMenuOpen(false)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-black/90 backdrop-blur-md border-b border-gray-800" : "bg-transparent"
      }`}
      role="banner"
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" role="navigation" aria-label="Main navigation">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="/" aria-label="ArtistLane Home">
              <ArtistLaneLogo size="md" />
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a
                href="#features"
                className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                aria-label="View features"
              >
                Features
              </a>
              <a
                href="#pricing"
                className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                aria-label="View pricing plans"
              >
                Pricing
              </a>
              <a
                href="#about"
                className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                aria-label="About ArtistLane"
              >
                About
              </a>
              <a
                href="#contact"
                className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                aria-label="Contact us"
              >
                Contact
              </a>
            </div>
          </div>

          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-gray-800" asChild>
              <a href="/signin" aria-label="Sign in to your account">
                Sign In
              </a>
            </Button>
            <Button
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium"
              asChild
            >
              <a href="/signup" aria-label="Create new account">
                Get Started
              </a>
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleMenu}
              className="text-gray-300 hover:text-white hover:bg-gray-800"
              aria-expanded={isMenuOpen}
              aria-controls="mobile-menu"
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div
            id="mobile-menu"
            className="md:hidden bg-black/95 backdrop-blur-md border-t border-gray-800"
            role="menu"
            aria-label="Mobile navigation menu"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a
                href="#features"
                className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium transition-colors"
                onClick={closeMenu}
                role="menuitem"
                aria-label="View features"
              >
                Features
              </a>
              <a
                href="#pricing"
                className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium transition-colors"
                onClick={closeMenu}
                role="menuitem"
                aria-label="View pricing plans"
              >
                Pricing
              </a>
              <a
                href="#about"
                className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium transition-colors"
                onClick={closeMenu}
                role="menuitem"
                aria-label="About ArtistLane"
              >
                About
              </a>
              <a
                href="#contact"
                className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium transition-colors"
                onClick={closeMenu}
                role="menuitem"
                aria-label="Contact us"
              >
                Contact
              </a>
              <div className="border-t border-gray-800 pt-4 pb-3">
                <div className="flex flex-col space-y-3 px-3">
                  <Button
                    variant="ghost"
                    className="text-gray-300 hover:text-white hover:bg-gray-800 justify-start"
                    asChild
                  >
                    <a href="/signin" onClick={closeMenu} aria-label="Sign in to your account">
                      Sign In
                    </a>
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-medium justify-start"
                    asChild
                  >
                    <a href="/signup" onClick={closeMenu} aria-label="Create new account">
                      Get Started
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
