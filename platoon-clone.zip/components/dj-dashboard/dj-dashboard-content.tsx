import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  TrendingUp,
  Play,
  Calendar,
  MapPin,
  Users,
  Upload,
  Headphones,
  DollarSign,
  Eye,
  Heart,
  Share2,
  MoreHorizontal,
} from "lucide-react"

interface DJDashboardContentProps {
  activeSection: string
}

export function DJDashboardContent({ activeSection }: DJDashboardContentProps) {
  // Get user name from localStorage
  const firstName = localStorage.getItem("userFirstName") || "DJ"
  const lastName = localStorage.getItem("userLastName") || ""
  const fullName = `${firstName} ${lastName}`.trim()

  const upcomingEvents = [
    {
      name: "Summer Vibes Festival",
      date: "July 25, 2025",
      time: "10:00 PM",
      venue: "Sunset Beach Club",
      attendees: "2,500",
      status: "confirmed",
      fee: "$2,500",
    },
    {
      name: "Underground Sessions",
      date: "July 30, 2025",
      time: "11:30 PM",
      venue: "The Warehouse",
      attendees: "800",
      status: "pending",
      fee: "$1,200",
    },
    {
      name: "Rooftop Party",
      date: "Aug 5, 2025",
      time: "9:00 PM",
      venue: "Sky Lounge",
      attendees: "1,200",
      status: "confirmed",
      fee: "$1,800",
    },
  ]

  const recentMixes = [
    {
      title: "Deep House Sunset",
      plays: "15,432",
      likes: "1,234",
      shares: "89",
      duration: "62 min",
      uploadDate: "2 days ago",
      image: "/placeholder.svg?height=80&width=80",
      genre: "Deep House",
    },
    {
      title: "Techno Underground",
      plays: "12,876",
      likes: "987",
      shares: "67",
      duration: "45 min",
      uploadDate: "5 days ago",
      image: "/placeholder.svg?height=80&width=80",
      genre: "Techno",
    },
    {
      title: "Progressive Journey",
      plays: "9,543",
      likes: "756",
      shares: "45",
      duration: "58 min",
      uploadDate: "1 week ago",
      image: "/placeholder.svg?height=80&width=80",
      genre: "Progressive",
    },
  ]

  if (activeSection === "upload") {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Upload Mix</h1>
          <p className="text-gray-400">Share your latest DJ mix with the world.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Upload DJ Mix</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 md:p-8 text-center hover:border-gray-500 transition-colors">
                <Headphones className="w-8 h-8 md:w-12 md:h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">Drop your mix here</h3>
                <p className="text-gray-400 mb-4">or click to browse</p>
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600">
                  Choose Mix File
                </Button>
                <p className="text-xs text-gray-500 mt-2">Supported formats: MP3, WAV, FLAC</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Mix Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Mix Title</label>
                <input
                  type="text"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white"
                  placeholder="Enter mix title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Genre</label>
                <select className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white">
                  <option>Deep House</option>
                  <option>Techno</option>
                  <option>Progressive</option>
                  <option>Trance</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Description</label>
                <textarea
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white h-24"
                  placeholder="Describe your mix..."
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (activeSection === "events") {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Events</h1>
            <p className="text-gray-400">Manage your upcoming performances and bookings.</p>
          </div>
          <Button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 mt-4 md:mt-0">
            <Calendar className="w-4 h-4 mr-2" />
            Book New Event
          </Button>
        </div>

        <div className="space-y-4">
          {upcomingEvents.map((event, index) => (
            <Card key={index} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors">
              <CardContent className="p-4 md:p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-semibold text-lg mb-1">{event.name}</h3>
                      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                        <span>
                          {event.date} at {event.time}
                        </span>
                        <span className="flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          {event.venue}
                        </span>
                        <span className="flex items-center">
                          <Users className="w-3 h-3 mr-1" />
                          {event.attendees}
                        </span>
                        <span className="flex items-center">
                          <DollarSign className="w-3 h-3 mr-1" />
                          {event.fee}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Badge
                      variant={event.status === "confirmed" ? "default" : "secondary"}
                      className={
                        event.status === "confirmed"
                          ? "bg-green-600 hover:bg-green-700"
                          : "bg-yellow-600 hover:bg-yellow-700"
                      }
                    >
                      {event.status}
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-gray-600 text-white hover:bg-gray-800 bg-transparent"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  // Default overview section
  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome back, {fullName}</h1>
        <p className="text-gray-400">Here's what's happening with your DJ career today.</p>
      </div>

      {/* Stats Grid - Mobile Responsive */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-gray-400">Total Plays</p>
                <p className="text-xl md:text-2xl font-bold text-white">847K</p>
              </div>
              <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-purple-400" />
              </div>
            </div>
            <div className="flex items-center text-xs md:text-sm text-green-500 mt-2">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +18.2%
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-gray-400">Events</p>
                <p className="text-xl md:text-2xl font-bold text-white">12</p>
              </div>
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Calendar className="w-4 h-4 text-blue-400" />
              </div>
            </div>
            <div className="flex items-center text-xs md:text-sm text-green-500 mt-2">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +3 new
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-gray-400">Earnings</p>
                <p className="text-xl md:text-2xl font-bold text-white">$8.4K</p>
              </div>
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-green-400" />
              </div>
            </div>
            <div className="flex items-center text-xs md:text-sm text-green-500 mt-2">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +25.1%
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm font-medium text-gray-400">Followers</p>
                <p className="text-xl md:text-2xl font-bold text-white">34.2K</p>
              </div>
              <div className="w-8 h-8 bg-pink-500/20 rounded-lg flex items-center justify-center">
                <Users className="w-4 h-4 text-pink-400" />
              </div>
            </div>
            <div className="flex items-center text-xs md:text-sm text-green-500 mt-2">
              <TrendingUp className="w-3 h-3 md:w-4 md:h-4 mr-1" />
              +12.8%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid - Mobile Responsive */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recent Mixes - Takes 2 columns on xl screens */}
        <Card className="bg-gray-900 border-gray-800 xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Recent Mixes</CardTitle>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              View All
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentMixes.map((mix, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-4 p-3 rounded-lg bg-gray-800/50 hover:bg-gray-800/70 transition-colors"
                >
                  <img
                    src={mix.image || "/placeholder.svg"}
                    alt={mix.title}
                    className="w-16 h-16 md:w-20 md:h-20 rounded-lg object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-white truncate">{mix.title}</h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {mix.genre}
                          </Badge>
                          <span className="text-xs text-gray-400">{mix.uploadDate}</span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-400 mt-2">
                          <span className="flex items-center">
                            <Play className="w-3 h-3 mr-1" />
                            {mix.plays}
                          </span>
                          <span className="flex items-center">
                            <Heart className="w-3 h-3 mr-1" />
                            {mix.likes}
                          </span>
                          <span className="flex items-center">
                            <Share2 className="w-3 h-3 mr-1" />
                            {mix.shares}
                          </span>
                          <span>{mix.duration}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white ml-2">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions Sidebar */}
        <div className="space-y-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 justify-start">
                <Upload className="w-4 h-4 mr-2" />
                Upload New Mix
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Event
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
              >
                <Eye className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
              <Button
                variant="outline"
                className="w-full border-gray-600 text-white hover:bg-gray-800 justify-start bg-transparent"
              >
                <Users className="w-4 h-4 mr-2" />
                Connect with Fans
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Next Event</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-white">Summer Vibes Festival</h4>
                  <p className="text-sm text-gray-400">July 25, 2025 - 3 days to go</p>
                </div>
                <Progress value={85} className="h-2" />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Preparation</span>
                  <span>85%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
