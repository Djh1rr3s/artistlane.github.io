"use client"

import { Button } from "@/components/ui/button"
import { Home, Calendar, MapPin, BarChart3, Upload, Users, Settings, Headphones, Mic } from "lucide-react"

interface DJDashboardSidebarProps {
  activeItem: string
  setActiveItem: (item: string) => void
}

export function DJDashboardSidebar({ activeItem, setActiveItem }: DJDashboardSidebarProps) {
  const menuItems = [
    { id: "overview", label: "Overview", icon: Home },
    { id: "mixes", label: "My Mixes", icon: Headphones },
    { id: "events", label: "Events", icon: Calendar },
    { id: "venues", label: "Venues", icon: MapPin },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "upload", label: "Upload Mix", icon: Upload },
    { id: "equipment", label: "Equipment", icon: Mic },
    { id: "audience", label: "Audience", icon: Users },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <aside className="w-64 bg-gray-900 border-r border-gray-800 min-h-screen">
      <nav className="p-4">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              className={`w-full justify-start text-left ${
                activeItem === item.id ? "bg-gray-800 text-white" : "text-gray-400 hover:text-white hover:bg-gray-800"
              }`}
              onClick={() => setActiveItem(item.id)}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.label}
            </Button>
          ))}
        </div>
      </nav>
    </aside>
  )
}
