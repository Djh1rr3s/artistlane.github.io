"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Home,
  Calendar,
  MapPin,
  BarChart3,
  Upload,
  Users,
  Settings,
  Headphones,
  Mic,
  Menu,
  X,
  Bell,
  Search,
  User,
  CreditCard,
  LogOut,
} from "lucide-react"
import { ArtistLaneLogo } from "@/components/artistlane-logo"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface DJSidebarToggleProps {
  activeItem: string
  setActiveItem: (item: string) => void
}

export function DJSidebarToggle({ activeItem, setActiveItem }: DJSidebarToggleProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  const menuItems = [
    { id: "overview", label: "Overview", icon: Home },
    { id: "mixes", label: "My Mixes", icon: Headphones },
    { id: "events", label: "Events", icon: Calendar },
    { id: "venues", label: "Venues", icon: MapPin },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "upload", label: "Upload Mix", icon: Upload },
    { id: "equipment", label: "Equipment", icon: Mic },
    { id: "audience", label: "Audience", icon: Users },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  const handleLogout = () => {
    localStorage.clear()
    window.location.href = "/"
  }

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between">
        <ArtistLaneLogo size="sm" />
        <div className="flex items-center space-x-2">
          <Badge className="bg-purple-600 text-white text-xs">🎧 DJ</Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileOpen(!isMobileOpen)}
            className="text-gray-400 hover:text-white"
          >
            {isMobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/50" onClick={() => setIsMobileOpen(false)}>
          <div className="w-64 h-full bg-gray-900 border-r border-gray-800" onClick={(e) => e.stopPropagation()}>
            <div className="p-4 border-b border-gray-800">
              <ArtistLaneLogo />
              <Badge className="bg-purple-600 text-white text-xs mt-2">🎧 DJ Dashboard</Badge>
            </div>
            <nav className="p-4">
              <div className="space-y-1">
                {menuItems.map((item) => (
                  <Button
                    key={item.id}
                    variant="ghost"
                    className={`w-full justify-start text-left ${
                      activeItem === item.id
                        ? "bg-purple-600 text-white"
                        : "text-gray-400 hover:text-white hover:bg-gray-800"
                    }`}
                    onClick={() => {
                      setActiveItem(item.id)
                      setIsMobileOpen(false)
                    }}
                  >
                    <item.icon className="w-4 h-4 mr-3" />
                    {item.label}
                  </Button>
                ))}
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col bg-gray-900 border-r border-gray-800 transition-all duration-300 ${
          isCollapsed ? "w-16" : "w-64"
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-gray-800 flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <ArtistLaneLogo size="sm" />
              <Badge className="bg-purple-600 text-white text-xs mt-2">🎧 DJ</Badge>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-gray-400 hover:text-white"
          >
            <Menu className="w-4 h-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-1">
            {menuItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                className={`w-full ${isCollapsed ? "justify-center px-2" : "justify-start"} text-left ${
                  activeItem === item.id
                    ? "bg-purple-600 text-white"
                    : "text-gray-400 hover:text-white hover:bg-gray-800"
                }`}
                onClick={() => setActiveItem(item.id)}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className={`w-4 h-4 ${!isCollapsed ? "mr-3" : ""}`} />
                {!isCollapsed && item.label}
              </Button>
            ))}
          </div>
        </nav>

        {/* User Menu */}
        <div className="p-4 border-t border-gray-800">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className={`w-full ${
                  isCollapsed ? "justify-center px-2" : "justify-start"
                } text-gray-400 hover:text-white hover:bg-gray-800`}
              >
                <User className={`w-4 h-4 ${!isCollapsed ? "mr-3" : ""}`} />
                {!isCollapsed && "Account"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-gray-800 border-gray-700" align="end">
              <DropdownMenuItem className="text-white hover:bg-gray-700">
                <User className="w-4 h-4 mr-2" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem className="text-white hover:bg-gray-700">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="text-red-400 hover:bg-gray-700">
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Top Bar for Desktop */}
      <div className="hidden lg:flex bg-gray-900 border-b border-gray-800 px-6 py-3 items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-semibold text-white capitalize">
            {menuItems.find((item) => item.id === activeItem)?.label || "Dashboard"}
          </h1>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search..."
              className="bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 w-64"
            />
          </div>

          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                <User className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-gray-800 border-gray-700">
              <DropdownMenuItem className="text-white hover:bg-gray-700">Profile</DropdownMenuItem>
              <DropdownMenuItem className="text-white hover:bg-gray-700">Settings</DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="text-red-400 hover:bg-gray-700">
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </>
  )
}
