import { Card, CardContent } from "@/components/ui/card"
import { Music, BarChart3, Globe, Headphones, DollarSign, Users } from "lucide-react"
import { PageContainer } from "@/components/layout/page-container"

export function FeaturesSection() {
  const features = [
    {
      icon: Music,
      title: "Global Distribution",
      description: "Distribute your music to 500+ platforms including Spotify, Apple Music, Amazon Music, and more.",
    },
    {
      icon: BarChart3,
      title: "Advanced Analytics",
      description:
        "Get detailed insights into your audience, streaming patterns, and revenue with real-time analytics.",
    },
    {
      icon: Globe,
      title: "Worldwide Reach",
      description: "Reach listeners in over 200 countries and territories with our global distribution network.",
    },
    {
      icon: Headphones,
      title: "DJ Services",
      description: "Specialized tools and distribution channels designed specifically for DJs and electronic music.",
    },
    {
      icon: DollarSign,
      title: "Revenue Optimization",
      description: "Maximize your earnings with our revenue optimization tools and transparent royalty reporting.",
    },
    {
      icon: Users,
      title: "Artist Support",
      description: "Get dedicated support from our team of music industry experts and marketing professionals.",
    },
  ]

  return (
    <section id="features" className="py-16 bg-gray-900" role="region" aria-labelledby="features-heading">
      <PageContainer maxWidth="2xl" padding="lg">
        <div className="text-center mb-12">
          <h2 id="features-heading" className="text-4xl md:text-5xl font-bold mb-4">
            Everything You Need to Succeed
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            From distribution to analytics, we provide all the tools you need to grow your music career and reach new
            audiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-all duration-300 group page-break-inside-avoid"
              role="article"
              aria-labelledby={`feature-${index}-title`}
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg mr-4 group-hover:from-purple-500/30 group-hover:to-pink-500/30 transition-all duration-300">
                    <feature.icon className="w-6 h-6 text-purple-400" aria-hidden="true" />
                  </div>
                  <h3 id={`feature-${index}-title`} className="text-xl font-semibold text-white">
                    {feature.title}
                  </h3>
                </div>
                <p className="text-gray-300 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </PageContainer>
    </section>
  )
}
