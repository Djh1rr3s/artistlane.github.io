import { Music } from "lucide-react"

interface ArtistLaneLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function ArtistLaneLogo({ className = "", size = "md", showText = true }: ArtistLaneLogoProps) {
  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-12 h-12",
  }

  const textSizes = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl",
  }

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-6 h-6",
  }

  return (
    <div className={`flex items-center space-x-2 ${className}`} role="img" aria-label="ArtistLane Logo">
      <div
        className={`${sizeClasses[size]} bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center shadow-lg`}
        aria-hidden="true"
      >
        <Music className={`${iconSizes[size]} text-white`} />
      </div>
      {showText && (
        <span
          className={`${textSizes[size]} font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent`}
        >
          ARTISTLANE
        </span>
      )}
      <span className="sr-only">ArtistLane - Music Distribution Platform</span>
    </div>
  )
}
