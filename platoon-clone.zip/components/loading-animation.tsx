"use client"

import { useEffect, useState } from "react"

export function LoadingAnimation() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (!isLoading) return null

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      <div className="relative">
        {/* Main loading circle with gradient */}
        <div className="w-16 h-16 border-2 border-gray-700 rounded-full animate-spin relative">
          <div className="absolute top-0 left-0 w-4 h-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
        </div>

        {/* Pulsing outer rings */}
        <div className="absolute inset-0 w-16 h-16 border border-gray-800 rounded-full animate-pulse"></div>
        <div className="absolute inset-[-8px] w-20 h-20 border border-gray-900 rounded-full animate-pulse animation-delay-300"></div>

        {/* Loading text */}
        <div className="absolute top-24 left-1/2 transform -translate-x-1/2 text-white text-sm font-medium">
          Loading...
        </div>

        {/* Subtle glow effect */}
        <div className="absolute inset-0 w-16 h-16 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-xl"></div>
      </div>
    </div>
  )
}
