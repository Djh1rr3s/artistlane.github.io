"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Lock, ArrowUp, Star } from "lucide-react"
import { UserFlowManager, type UserPlan } from "@/utils/user-flow-manager"

interface FeatureGateProps {
  feature: string
  requiredPlan?: string
  children: React.ReactNode
  fallback?: React.ReactNode
}

export function FeatureGate({ feature, requiredPlan, children, fallback }: FeatureGateProps) {
  const [hasAccess, setHasAccess] = useState(false)
  const [currentPlan, setCurrentPlan] = useState<UserPlan | null>(null)
  const [userRole, setUserRole] = useState<"artist" | "dj">("artist")

  const userFlowManager = UserFlowManager.getInstance()

  useEffect(() => {
    const hasFeatureAccess = userFlowManager.hasFeatureAccess(feature)
    const activePlan = localStorage.getItem("activePlan")
    const role = localStorage.getItem("userRole") as "artist" | "dj"

    setHasAccess(hasFeatureAccess)
    setUserRole(role || "artist")

    if (activePlan) {
      setCurrentPlan(JSON.parse(activePlan))
    }
  }, [feature])

  if (hasAccess) {
    return <>{children}</>
  }

  if (fallback) {
    return <>{fallback}</>
  }

  // Default upgrade prompt
  return (
    <Card className="bg-gray-900/50 border-gray-800 border-dashed">
      <CardHeader className="text-center pb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-purple-400" />
        </div>
        <CardTitle className="text-white flex items-center justify-center gap-2">
          <span>Upgrade Required</span>
          <ArrowUp className="w-4 h-4 text-orange-500" />
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <div className="space-y-2">
          <p className="text-gray-400">This feature requires a {requiredPlan || "Professional"} plan or higher.</p>
          {currentPlan && (
            <div className="flex items-center justify-center gap-2">
              <span className="text-sm text-gray-500">Current plan:</span>
              <Badge variant="secondary" className="bg-gray-800 text-gray-300">
                {currentPlan.planName}
              </Badge>
            </div>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button
            onClick={() => (window.location.href = `/${userRole === "dj" ? "dj-dashboard" : "dashboard"}?tab=billing`)}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
          >
            <Star className="w-4 h-4 mr-2" />
            Upgrade Plan
          </Button>
          <Button
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
            onClick={() => (window.location.href = "mailto:sales@artistlane.com")}
          >
            Contact Sales
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
