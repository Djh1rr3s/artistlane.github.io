"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, CheckCircle, ArrowUp } from "lucide-react"
import { UserFlowManager } from "@/utils/user-flow-manager"

interface UsageIndicatorProps {
  feature: string
  current: number
  label: string
}

export function UsageIndicator({ feature, current, label }: UsageIndicatorProps) {
  const [limitations, setLimitations] = useState<{ [key: string]: number | boolean }>({})
  const [planName, setPlanName] = useState<string>("")

  const userFlowManager = UserFlowManager.getInstance()

  useEffect(() => {
    const planLimitations = userFlowManager.getPlanLimitations()
    const activePlan = localStorage.getItem("activePlan")

    setLimitations(planLimitations)

    if (activePlan) {
      const plan = JSON.parse(activePlan)
      setPlanName(plan.planName)
    }
  }, [])

  const getFeatureLimit = (): number => {
    const featureKey = `max${feature.charAt(0).toUpperCase() + feature.slice(1)}`
    const limit = limitations[featureKey] as number
    return limit === -1 ? Number.POSITIVE_INFINITY : limit || 0
  }

  const limit = getFeatureLimit()
  const percentage = limit === Number.POSITIVE_INFINITY ? 0 : Math.min((current / limit) * 100, 100)
  const isNearLimit = percentage > 80
  const isAtLimit = current >= limit && limit !== Number.POSITIVE_INFINITY

  if (limit === Number.POSITIVE_INFINITY) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-300">{label}</p>
              <p className="text-2xl font-bold text-white">{current.toLocaleString()}</p>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <Badge className="bg-green-600 text-white">Unlimited</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card
      className={`bg-gray-900 border-gray-800 ${isAtLimit ? "border-red-500/50" : isNearLimit ? "border-yellow-500/50" : ""}`}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-gray-300">{label}</CardTitle>
          <div className="flex items-center space-x-2">
            {isAtLimit ? (
              <AlertTriangle className="w-4 h-4 text-red-500" />
            ) : isNearLimit ? (
              <AlertTriangle className="w-4 h-4 text-yellow-500" />
            ) : (
              <CheckCircle className="w-4 h-4 text-green-500" />
            )}
            <Badge
              variant={isAtLimit ? "destructive" : isNearLimit ? "secondary" : "default"}
              className={
                isAtLimit
                  ? "bg-red-600 text-white"
                  : isNearLimit
                    ? "bg-yellow-600 text-white"
                    : "bg-green-600 text-white"
              }
            >
              {planName}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{current.toLocaleString()}</span>
            <span className="text-sm text-gray-400">of {limit.toLocaleString()}</span>
          </div>

          <Progress
            value={percentage}
            className={`h-2 ${isAtLimit ? "bg-red-900" : isNearLimit ? "bg-yellow-900" : "bg-gray-700"}`}
          />

          <div className="flex items-center justify-between text-xs">
            <span className={`${isAtLimit ? "text-red-400" : isNearLimit ? "text-yellow-400" : "text-gray-400"}`}>
              {percentage.toFixed(1)}% used
            </span>
            {(isAtLimit || isNearLimit) && (
              <button
                onClick={() => (window.location.href = "/dashboard?tab=billing")}
                className="text-purple-400 hover:text-purple-300 flex items-center gap-1"
              >
                <ArrowUp className="w-3 h-3" />
                Upgrade
              </button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
