"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star, ArrowUp, ArrowDown } from "lucide-react"
import { PaymentModal } from "@/components/payment/payment-modal"

interface Plan {
  name: string
  price: string
  description: string
  features: string[]
  popular: boolean
  type: "artist" | "dj"
}

export function PlanManagement() {
  const [currentPlan, setCurrentPlan] = useState<Plan | null>(null)
  const [userType, setUserType] = useState<"artist" | "dj">("artist")
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null)

  const artistPlans: Plan[] = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for emerging artists",
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      popular: false,
      type: "artist",
    },
    {
      name: "Professional",
      price: "$39.99/year",
      description: "For serious artists and labels",
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "Marketing tools",
        "Custom release scheduling",
        "Revenue optimization",
      ],
      popular: true,
      type: "artist",
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For labels and large catalogs",
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      popular: false,
      type: "artist",
    },
  ]

  const djPlans: Plan[] = [
    {
      name: "Regular",
      price: "$49.99/year",
      description: "Perfect for emerging DJs",
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      popular: false,
      type: "dj",
    },
    {
      name: "Professional",
      price: "$89.99/year",
      description: "For serious DJs and labels",
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "Marketing tools",
        "Custom release scheduling",
        "Revenue optimization",
      ],
      popular: true,
      type: "dj",
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For labels and large catalogs",
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      popular: false,
      type: "dj",
    },
  ]

  useEffect(() => {
    // Get current user plan and type
    const activePlan = localStorage.getItem("activePlan")
    const role = localStorage.getItem("userRole") as "artist" | "dj"

    if (activePlan) {
      setCurrentPlan(JSON.parse(activePlan))
    }
    if (role) {
      setUserType(role)
    }
  }, [])

  const plans = userType === "artist" ? artistPlans : djPlans

  const handlePlanChange = (plan: Plan) => {
    if (plan.price === "Custom") {
      window.location.href = "mailto:sales@artistlane.com"
      return
    }

    setSelectedPlan(plan)

    if (plan.price === "Free") {
      // Immediate downgrade to free
      localStorage.setItem("activePlan", JSON.stringify(plan))
      setCurrentPlan(plan)
      // Show success message or redirect
      window.location.reload()
    } else {
      setShowPaymentModal(true)
    }
  }

  const getPlanChangeType = (plan: Plan) => {
    if (!currentPlan) return "upgrade"

    const currentIndex = plans.findIndex((p) => p.name === currentPlan.name)
    const newIndex = plans.findIndex((p) => p.name === plan.name)

    if (newIndex > currentIndex) return "upgrade"
    if (newIndex < currentIndex) return "downgrade"
    return "current"
  }

  const getPlanChangeIcon = (changeType: string) => {
    switch (changeType) {
      case "upgrade":
        return <ArrowUp className="w-4 h-4 text-green-500" />
      case "downgrade":
        return <ArrowDown className="w-4 h-4 text-orange-500" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold mb-4 text-white">Manage Your Plan</h2>
        <p className="text-gray-400">
          {currentPlan ? `You're currently on the ${currentPlan.name} plan` : "Choose the perfect plan for your needs"}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan, index) => {
          const changeType = getPlanChangeType(plan)
          const isCurrentPlan = currentPlan?.name === plan.name

          return (
            <Card
              key={index}
              className={`relative bg-gray-900 border-gray-800 hover:border-gray-600 transition-all duration-300 ${
                plan.popular ? "border-purple-500 scale-105" : ""
              } ${isCurrentPlan ? "ring-2 ring-blue-500" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                    <Star className="w-4 h-4 mr-1 fill-current" />
                    Most Popular
                  </div>
                </div>
              )}

              {isCurrentPlan && (
                <div className="absolute -top-3 right-4">
                  <Badge className="bg-blue-600 hover:bg-blue-700">Current Plan</Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl font-bold text-white flex items-center justify-center gap-2">
                  {plan.name}
                  {!isCurrentPlan && getPlanChangeIcon(changeType)}
                </CardTitle>
                <div className="text-2xl font-bold text-white mb-2">{plan.price}</div>
                <p className="text-gray-400 text-sm">{plan.description}</p>
              </CardHeader>

              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start text-gray-300 text-sm">
                      <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button
                  onClick={() => handlePlanChange(plan)}
                  disabled={isCurrentPlan}
                  className={`w-full ${
                    isCurrentPlan
                      ? "bg-gray-700 text-gray-400 cursor-not-allowed"
                      : changeType === "upgrade"
                        ? "bg-gradient-to-r from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700"
                        : changeType === "downgrade"
                          ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700"
                          : "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                  }`}
                >
                  {isCurrentPlan
                    ? "Current Plan"
                    : changeType === "upgrade"
                      ? "Upgrade"
                      : changeType === "downgrade"
                        ? "Downgrade"
                        : plan.price === "Custom"
                          ? "Contact Sales"
                          : "Select Plan"}
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Payment Modal */}
      {showPaymentModal && selectedPlan && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          plan={{
            planName: selectedPlan.name,
            price: selectedPlan.price,
            type: selectedPlan.type,
          }}
        />
      )}
    </div>
  )
}
