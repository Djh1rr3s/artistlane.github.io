"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Crown, Zap } from "lucide-react"
import { PageContainer } from "@/components/layout/page-container"

export function ServicesSection() {
  const [activeTab, setActiveTab] = useState("artist")

  const artistPlans = [
    {
      name: "Starter",
      price: "Free",
      period: "",
      description: "Perfect for emerging artists",
      icon: Zap,
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      buttonText: "Get Started",
      buttonLink: "/signup",
      popular: false,
    },
    {
      name: "Professional",
      price: "$39.99",
      period: "/year",
      description: "For serious artists and labels",
      icon: Star,
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "Marketing tools",
        "Custom release scheduling",
        "Revenue optimization",
      ],
      buttonText: "Get Started",
      buttonLink: "/signup",
      popular: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "",
      description: "For labels and large catalogs",
      icon: Crown,
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      buttonText: "Contact Sales",
      buttonLink: "/contact",
      popular: false,
    },
  ]

  const djPlans = [
    {
      name: "Regular",
      price: "$49.99",
      period: "/year",
      description: "Essential tools for DJs",
      icon: Zap,
      features: ["Distribute to 5 platforms", "Basic analytics", "Community support", "Standard quality control"],
      buttonText: "Get Started",
      buttonLink: "/signup",
      popular: false,
    },
    {
      name: "Professional",
      price: "$99.99",
      period: "/year",
      description: "Advanced DJ features",
      icon: Star,
      features: [
        "Distribute to all platforms",
        "Advanced analytics & insights",
        "Priority support",
        "DJ-specific marketing tools",
        "Event promotion tools",
        "Mix hosting & streaming",
      ],
      buttonText: "Get Started",
      buttonLink: "/signup",
      popular: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "",
      description: "For DJ agencies and collectives",
      icon: Crown,
      features: [
        "Everything in Professional",
        "Dedicated account manager",
        "Custom integrations",
        "White-label solutions",
        "Advanced reporting",
        "Priority distribution",
      ],
      buttonText: "Contact Sales",
      buttonLink: "/contact",
      popular: false,
    },
  ]

  const currentPlans = activeTab === "artist" ? artistPlans : djPlans

  return (
    <section className="py-16 bg-black" role="region" aria-labelledby="services-heading">
      <PageContainer maxWidth="2xl" padding="lg">
        <div className="text-center mb-12">
          <h2 id="services-heading" className="text-4xl md:text-5xl font-bold mb-4">
            Choose Your Plan
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-8">
            Select the perfect plan for your music career. Whether you're an artist or DJ, we have the tools you need.
          </p>

          {/* Tab Navigation */}
          <div className="flex justify-center mb-8" role="tablist" aria-label="Plan types">
            <div className="bg-gray-800 p-1 rounded-lg">
              <button
                className={`px-6 py-2 rounded-md transition-all duration-200 ${
                  activeTab === "artist"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                    : "text-gray-400 hover:text-white"
                }`}
                onClick={() => setActiveTab("artist")}
                role="tab"
                aria-selected={activeTab === "artist"}
                aria-controls="artist-plans"
                id="artist-tab"
              >
                Artist Plans
              </button>
              <button
                className={`px-6 py-2 rounded-md transition-all duration-200 ${
                  activeTab === "dj"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                    : "text-gray-400 hover:text-white"
                }`}
                onClick={() => setActiveTab("dj")}
                role="tab"
                aria-selected={activeTab === "dj"}
                aria-controls="dj-plans"
                id="dj-tab"
              >
                DJ Plans
              </button>
            </div>
          </div>
        </div>

        {/* Plans Grid */}
        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          role="tabpanel"
          id={`${activeTab}-plans`}
          aria-labelledby={`${activeTab}-tab`}
        >
          {currentPlans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-gray-900/50 border-gray-800 hover:border-gray-600 transition-all duration-300 page-break-inside-avoid ${
                plan.popular ? "ring-1 ring-purple-500" : ""
              }`}
              role="article"
              aria-labelledby={`plan-${index}-title`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  Most Popular
                </Badge>
              )}

              <CardHeader className="text-center pb-4">
                <div className="flex items-center justify-center mb-4">
                  <div className="p-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg">
                    <plan.icon className="w-8 h-8 text-purple-400" aria-hidden="true" />
                  </div>
                </div>
                <CardTitle id={`plan-${index}-title`} className="text-2xl font-bold text-white mb-2">
                  {plan.name}
                </CardTitle>
                <p className="text-gray-400 mb-4">{plan.description}</p>
                <div className="text-center">
                  <span className="text-4xl font-bold text-white">{plan.price}</span>
                  <span className="text-gray-400">{plan.period}</span>
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3 mb-6" role="list">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-300">
                      <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" aria-hidden="true" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
                      : "bg-gray-800 text-white hover:bg-gray-700"
                  }`}
                  asChild
                >
                  <a href={plan.buttonLink} aria-label={`${plan.buttonText} for ${plan.name} plan`}>
                    {plan.buttonText}
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </PageContainer>
    </section>
  )
}
