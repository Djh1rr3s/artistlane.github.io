"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  User,
  Mail,
  Music,
  Instagram,
  Twitter,
  Youtube,
  Globe,
  Camera,
  Save,
  LinkIcon,
  AirplayIcon as Spotify,
  Facebook,
} from "lucide-react"

interface UserProfile {
  firstName: string
  lastName: string
  stageName: string
  email: string
  bio: string
  location: string
  website: string
  avatar: string
  socialMedia: {
    instagram: string
    twitter: string
    youtube: string
    spotify: string
    facebook: string
    soundcloud: string
  }
}

export function ProfileEditor() {
  const [profile, setProfile] = useState<UserProfile>({
    firstName: "",
    lastName: "",
    stageName: "",
    email: "",
    bio: "",
    location: "",
    website: "",
    avatar: "",
    socialMedia: {
      instagram: "",
      twitter: "",
      youtube: "",
      spotify: "",
      facebook: "",
      soundcloud: "",
    },
  })
  const [isLoading, setIsLoading] = useState(false)
  const [userRole, setUserRole] = useState<"artist" | "dj">("artist")

  useEffect(() => {
    // Load existing profile data
    const firstName = localStorage.getItem("userFirstName") || ""
    const lastName = localStorage.getItem("userLastName") || ""
    const email = localStorage.getItem("userEmail") || ""
    const role = localStorage.getItem("userRole") as "artist" | "dj"
    const savedProfile = localStorage.getItem("userProfile")

    setUserRole(role || "artist")

    if (savedProfile) {
      setProfile(JSON.parse(savedProfile))
    } else {
      setProfile((prev) => ({
        ...prev,
        firstName,
        lastName,
        email,
      }))
    }
  }, [])

  const handleInputChange = (field: string, value: string) => {
    if (field.startsWith("socialMedia.")) {
      const socialField = field.split(".")[1]
      setProfile((prev) => ({
        ...prev,
        socialMedia: {
          ...prev.socialMedia,
          [socialField]: value,
        },
      }))
    } else {
      setProfile((prev) => ({
        ...prev,
        [field]: value,
      }))
    }
  }

  const handleSave = async () => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Save to localStorage
    localStorage.setItem("userProfile", JSON.stringify(profile))
    localStorage.setItem("userFirstName", profile.firstName)
    localStorage.setItem("userLastName", profile.lastName)
    localStorage.setItem("userEmail", profile.email)

    setIsLoading(false)

    // Show success message (you could add a toast notification here)
    alert("Profile updated successfully!")
  }

  const getInitials = () => {
    return `${profile.firstName.charAt(0)}${profile.lastName.charAt(0)}`.toUpperCase()
  }

  const socialMediaPlatforms = [
    { key: "instagram", label: "Instagram", icon: Instagram, placeholder: "@username" },
    { key: "twitter", label: "Twitter", icon: Twitter, placeholder: "@username" },
    { key: "youtube", label: "YouTube", icon: Youtube, placeholder: "Channel URL" },
    { key: "spotify", label: "Spotify", icon: Spotify, placeholder: "Artist URL" },
    { key: "facebook", label: "Facebook", icon: Facebook, placeholder: "Page URL" },
    { key: "soundcloud", label: "SoundCloud", icon: Globe, placeholder: "Profile URL" },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold mb-4 text-white">Edit Profile</h2>
        <p className="text-gray-400">Update your profile information and social media links</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Picture and Basic Info */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Profile Picture</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="relative inline-block">
              <Avatar className="w-24 h-24 mx-auto">
                <AvatarImage src={profile.avatar || "/placeholder.svg"} />
                <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-xl">
                  {getInitials()}
                </AvatarFallback>
              </Avatar>
              <Button
                size="sm"
                className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0 bg-gradient-to-r from-purple-500 to-pink-500"
              >
                <Camera className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2">
              <Badge variant="secondary" className="bg-gray-800 text-gray-300">
                {userRole === "artist" ? "🎵 Artist" : "🎧 DJ"}
              </Badge>
              <p className="text-gray-400 text-sm">Click the camera icon to upload a new photo</p>
            </div>
          </CardContent>
        </Card>

        {/* Basic Information */}
        <Card className="bg-gray-900 border-gray-800 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white">Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-gray-300 font-medium">
                  First Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="firstName"
                    value={profile.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white pl-10"
                    placeholder="John"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="lastName" className="text-gray-300 font-medium">
                  Last Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="lastName"
                    value={profile.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white pl-10"
                    placeholder="Doe"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="stageName" className="text-gray-300 font-medium">
                {userRole === "artist" ? "Artist Name / Stage Name" : "DJ Name"}
              </Label>
              <div className="relative">
                <Music className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="stageName"
                  value={profile.stageName}
                  onChange={(e) => handleInputChange("stageName", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  placeholder={userRole === "artist" ? "Your artist name" : "Your DJ name"}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-300 font-medium">
                Email Address
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  placeholder="john.doe@example.com"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="location" className="text-gray-300 font-medium">
                Location
              </Label>
              <Input
                id="location"
                value={profile.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                placeholder="City, Country"
              />
            </div>

            <div>
              <Label htmlFor="website" className="text-gray-300 font-medium">
                Website
              </Label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="website"
                  value={profile.website}
                  onChange={(e) => handleInputChange("website", e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white pl-10"
                  placeholder="https://yourwebsite.com"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="bio" className="text-gray-300 font-medium">
                Bio
              </Label>
              <Textarea
                id="bio"
                value={profile.bio}
                onChange={(e) => handleInputChange("bio", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                placeholder={`Tell us about yourself as ${userRole === "artist" ? "an artist" : "a DJ"}...`}
                rows={4}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Social Media Links */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Social Media Links</CardTitle>
          <p className="text-gray-400 text-sm">Connect your social media accounts to grow your audience</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {socialMediaPlatforms.map((platform) => (
              <div key={platform.key}>
                <Label htmlFor={platform.key} className="text-gray-300 font-medium">
                  {platform.label}
                </Label>
                <div className="relative">
                  <platform.icon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id={platform.key}
                    value={profile.socialMedia[platform.key as keyof typeof profile.socialMedia]}
                    onChange={(e) => handleInputChange(`socialMedia.${platform.key}`, e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white pl-10"
                    placeholder={platform.placeholder}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={isLoading}
          className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 px-8"
        >
          {isLoading ? (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              <span>Saving...</span>
            </div>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
